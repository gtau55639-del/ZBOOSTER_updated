package com.zbooster.app.ui.components

import android.graphics.drawable.Drawable
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.zbooster.app.model.Game
import com.zbooster.app.model.OptimizationStatus
import com.zbooster.app.ui.theme.ZSuccess
import com.zbooster.app.ui.theme.ZSurfaceBorder
import com.zbooster.app.ui.theme.ZTextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun GameCard(
    game: Game,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    // Loaded off the main thread and cached per-composable-instance, so
    // scrolling the grid never blocks on disk/PackageManager work (spec
    // #11: lazy loading, don't load all icons at once synchronously).
    var icon by remember(game.packageName) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(game.packageName) {
        icon = withContext(Dispatchers.IO) { loadAppIcon(context, game.packageName) }
    }

    ZCard(modifier = modifier.clickable(onClick = onClick)) {
        Column(Modifier.padding(12.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                val currentIcon = icon
                if (currentIcon != null) {
                    androidx.compose.foundation.Image(
                        painter = BitmapPainter(currentIcon.asImageBitmap()),
                        contentDescription = game.appName,
                        modifier = Modifier
                            .fillMaxSize(0.68f)
                            .clip(RoundedCornerShape(10.dp))
                    )
                } else {
                    Icon(
                        Icons.Filled.SportsEsports,
                        contentDescription = game.appName,
                        tint = ZTextSecondary,
                        modifier = Modifier.size(32.dp)
                    )
                }

                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(28.dp)
                ) {
                    Icon(
                        imageVector = if (game.isFavorite) Icons.Filled.Star else Icons.Outlined.Star,
                        contentDescription = "Favorite",
                        tint = if (game.isFavorite) ZSuccess else ZTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            Text(
                text = game.appName,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(Modifier.height(2.dp))

            OptimizationBadge(status = game.optimizationStatus)
        }
    }
}

@Composable
private fun OptimizationBadge(status: OptimizationStatus) {
    val (text, color) = when (status) {
        OptimizationStatus.OPTIMIZED -> "Optimized" to ZSuccess
        OptimizationStatus.NOT_OPTIMIZED -> "Not Optimized" to ZTextSecondary
        OptimizationStatus.NOT_SUPPORTED -> "Not Supported" to ZTextSecondary
    }
    Text(text = text, style = MaterialTheme.typography.labelSmall, color = color)
}

/** Loads a launcher icon bitmap via PackageManager — no fabricated placeholder art. */
private fun loadAppIcon(context: android.content.Context, packageName: String): android.graphics.Bitmap? {
    return try {
        val drawable: Drawable = context.packageManager.getApplicationIcon(packageName)
        drawableToBitmap(drawable)
    } catch (e: Exception) {
        null
    }
}

private fun drawableToBitmap(drawable: Drawable): android.graphics.Bitmap {
    if (drawable is android.graphics.drawable.BitmapDrawable) return drawable.bitmap
    val width = drawable.intrinsicWidth.coerceAtLeast(1)
    val height = drawable.intrinsicHeight.coerceAtLeast(1)
    val bitmap = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    drawable.setBounds(0, 0, canvas.width, canvas.height)
    drawable.draw(canvas)
    return bitmap
}
