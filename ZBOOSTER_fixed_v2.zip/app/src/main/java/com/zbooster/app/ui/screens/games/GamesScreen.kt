@file:OptIn(ExperimentalMaterial3Api::class)

package com.zbooster.app.ui.screens.games

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zbooster.app.model.GameCategory
import com.zbooster.app.ui.components.GameCard
import com.zbooster.app.ui.theme.ZTextSecondary
import com.zbooster.app.ui.theme.ZWindowSize
import com.zbooster.app.ui.theme.contentPadding
import com.zbooster.app.ui.theme.gameGridColumns

@Composable
fun GamesScreen(
    windowSize: ZWindowSize,
    onGameClick: (String) -> Unit,
    viewModel: GamesViewModel = viewModel()
) {
    val games by viewModel.filteredGames.collectAsStateWithLifecycle()
    val query by viewModel.searchQuery.collectAsStateWithLifecycle()
    val category by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val loadState by viewModel.loadState.collectAsStateWithLifecycle()

    val padding = windowSize.contentPadding().dp
    val columns = windowSize.gameGridColumns()

    LaunchedEffect(Unit) { viewModel.refresh() }

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = padding, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Game Library",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = { viewModel.refresh() }) {
                Icon(Icons.Filled.Refresh, contentDescription = "Refresh Game List")
            }
        }

        OutlinedTextField(
            value = query,
            onValueChange = viewModel::onSearchQueryChanged,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = padding),
            placeholder = { Text("Search games") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true,
            shape = MaterialTheme.shapes.medium
        )

        Spacer(Modifier.height(12.dp))

        CategoryChipsRow(
            selected = category,
            onSelected = viewModel::onCategorySelected,
            padding = padding
        )

        Spacer(Modifier.height(8.dp))

        when (loadState) {
            GamesLoadState.LOADING -> LoadingState()
            GamesLoadState.EMPTY -> EmptyState()
            GamesLoadState.PERMISSION_LIMITED -> PermissionLimitedState()
            GamesLoadState.LOADED -> {
                if (games.isEmpty()) {
                    EmptyState(message = "No games match your search or filter.")
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(columns),
                        contentPadding = PaddingValues(horizontal = padding, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(games, key = { it.packageName }) { game ->
                            GameCard(
                                game = game,
                                onClick = { onGameClick(game.packageName) },
                                onToggleFavorite = {
                                    viewModel.toggleFavorite(game.packageName, !game.isFavorite)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryChipsRow(
    selected: GameCategory,
    onSelected: (GameCategory) -> Unit,
    padding: Dp
) {
    val categories = listOf(
        GameCategory.ALL to "All Games",
        GameCategory.RECENTLY_PLAYED to "Recently Played",
        GameCategory.FAVORITE to "Favorite",
        GameCategory.HIGH_PERFORMANCE to "High Performance",
        GameCategory.CUSTOM to "Custom"
    )

    LazyRow(
        contentPadding = PaddingValues(horizontal = padding),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(categories.size) { index ->
            val (cat, label) = categories[index]
            FilterChip(
                selected = selected == cat,
                onClick = { onSelected(cat) },
                label = { Text(label) }
            )
        }
    }
}

@Composable
private fun LoadingState() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
    }
}

@Composable
private fun EmptyState(message: String = "No games detected yet. Install a game or pull to refresh.") {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Filled.SportsEsports,
            contentDescription = null,
            tint = ZTextSecondary,
            modifier = Modifier.size(48.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, color = ZTextSecondary)
    }
}

@Composable
private fun PermissionLimitedState() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "ZBOOSTER needs access to your installed apps list to show your games here.",
            style = MaterialTheme.typography.bodyMedium,
            color = ZTextSecondary
        )
    }
}
