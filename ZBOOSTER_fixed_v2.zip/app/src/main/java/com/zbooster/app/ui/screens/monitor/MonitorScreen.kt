@file:OptIn(ExperimentalMaterial3Api::class)

package com.zbooster.app.ui.screens.monitor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zbooster.app.model.MonitorGraphMode
import com.zbooster.app.model.PerformanceSample
import com.zbooster.app.ui.components.ZCard
import com.zbooster.app.ui.theme.*

@Composable
fun MonitorScreen(viewModel: MonitorViewModel = viewModel()) {
    val isLive by viewModel.isLive.collectAsStateWithLifecycle()
    val graphMode by viewModel.graphMode.collectAsStateWithLifecycle()
    val latest by viewModel.latest.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Performance Monitor", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Button(onClick = { viewModel.toggleLive() }) {
                    Icon(if (isLive) Icons.Filled.Stop else Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (isLive) "Stop" else "Start")
                }
            }
        }

        item { GraphModeSelector(selected = graphMode, onSelect = viewModel::setGraphMode) }

        item {
            if (!isLive) {
                ZCard {
                    Text(
                        "Monitoring is off to save battery. Tap Start to begin live tracking.",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ZTextSecondary
                    )
                }
            } else if (latest == null) {
                ZCard {
                    Box(Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            } else {
                MetricsGrid(sample = latest!!, detailed = graphMode == MonitorGraphMode.DETAILED)
            }
        }

        if (isLive && graphMode != MonitorGraphMode.SIMPLE && history.size > 1) {
            item { RamHistoryChart(history) }
        }
    }
}

@Composable
private fun GraphModeSelector(selected: MonitorGraphMode, onSelect: (MonitorGraphMode) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MonitorGraphMode.entries.forEach { mode ->
            FilterChip(
                selected = selected == mode,
                onClick = { onSelect(mode) },
                label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }
            )
        }
    }
}

@Composable
private fun MetricsGrid(sample: PerformanceSample, detailed: Boolean) {
    ZCard {
        Column(Modifier.padding(16.dp)) {
            MetricLine("RAM Usage", "${sample.ramUsagePercent}%")
            MetricLine("Battery", "${sample.batteryPercent}%")
            MetricLine(
                "CPU Usage",
                sample.cpuUsagePercent?.let { "$it%" } ?: "Not available on this device"
            )
            MetricLine(
                "Temperature",
                sample.temperatureCelsius?.let { "${it}°C" } ?: "Not available on this device"
            )
            MetricLine("Network", sample.networkType)
            if (detailed) {
                MetricLine(
                    "FPS",
                    if (sample.fpsAvailable) "${sample.fps}" else "FPS cannot be read universally on this device"
                )
            }
        }
    }
}

@Composable
private fun MetricLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = ZTextSecondary)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

/**
 * Deliberately simple line chart drawn with Canvas — no external charting
 * library — to keep the app light on low-end devices (spec #11/#8).
 */
@Composable
private fun RamHistoryChart(history: List<PerformanceSample>) {
    ZCard {
        Column(Modifier.padding(16.dp)) {
            Text("RAM Usage (last ${history.size} samples)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
            ) {
                if (history.size < 2) return@Canvas
                val maxVal = 100f
                val stepX = size.width / (history.size - 1)
                val points = history.mapIndexed { index, sample ->
                    Offset(
                        x = index * stepX,
                        y = size.height - (sample.ramUsagePercent / maxVal) * size.height
                    )
                }
                for (i in 0 until points.size - 1) {
                    drawLine(
                        color = ZCyberBlue,
                        start = points[i],
                        end = points[i + 1],
                        strokeWidth = 4f,
                        cap = StrokeCap.Round
                    )
                }
            }
        }
    }
}
