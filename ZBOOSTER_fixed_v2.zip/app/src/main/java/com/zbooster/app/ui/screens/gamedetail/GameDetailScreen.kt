@file:OptIn(ExperimentalMaterial3Api::class)

package com.zbooster.app.ui.screens.gamedetail

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zbooster.app.model.BoosterProfileType
import com.zbooster.app.model.Game
import com.zbooster.app.ui.components.ZCard
import com.zbooster.app.ui.theme.ZTextSecondary

@Composable
fun GameDetailScreen(
    packageName: String,
    onBack: () -> Unit,
    viewModel: GameDetailViewModel = viewModel()
) {
    val context = LocalContext.current
    val game by viewModel.game.collectAsStateWithLifecycle()
    val isLaunching by viewModel.isLaunching.collectAsStateWithLifecycle()

    LaunchedEffect(packageName) { viewModel.load(packageName) }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(game?.appName ?: "Game Details") },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                }
            }
        )

        val currentGame = game
        if (currentGame == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Column
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { ProfileSelector(currentGame, onSelect = { viewModel.setProfile(packageName, it) }) }
            item { GameProfileInfoCard(currentGame) }
            item {
                Button(
                    onClick = {
                        viewModel.prepareLaunch(packageName) { intent ->
                            if (intent != null) context.startActivity(intent)
                        }
                    },
                    enabled = !isLaunching,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = MaterialTheme.shapes.large
                ) {
                    if (isLaunching) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(10.dp))
                        Text("Preparing…")
                    } else {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("PLAY GAME", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileSelector(game: Game, onSelect: (BoosterProfileType) -> Unit) {
    ZCard {
        Column(Modifier.padding(16.dp)) {
            Text("Booster Profile", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            // Horizontally scrollable chip row keeps this compatible across
            // Compose Foundation versions without relying on experimental FlowRow.
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BoosterProfileType.entries.forEach { profile ->
                    FilterChip(
                        selected = game.boosterProfile == profile,
                        onClick = { onSelect(profile) },
                        label = { Text(profile.name.replace('_', ' ')) }
                    )
                }
            }
        }
    }
}

@Composable
private fun GameProfileInfoCard(game: Game) {
    ZCard {
        Column(Modifier.padding(16.dp)) {
            Text("Profile Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            InfoRow(label = "FPS Profile", value = fpsProfileFor(game.boosterProfile))
            InfoRow(label = "Touch Response", value = touchProfileFor(game.boosterProfile))
            InfoRow(label = "DND Mode", value = "Follows Settings")
            InfoRow(label = "Battery Mode", value = batteryModeFor(game.boosterProfile))
            InfoRow(label = "Network Preference", value = "Auto")
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = ZTextSecondary)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

private fun fpsProfileFor(profile: BoosterProfileType) = when (profile) {
    BoosterProfileType.EXTREME -> "Maximum (device-dependent)"
    BoosterProfileType.PERFORMANCE -> "High"
    BoosterProfileType.BATTERY_SAVER -> "Capped for efficiency"
    else -> "Standard"
}

private fun touchProfileFor(profile: BoosterProfileType) = when (profile) {
    BoosterProfileType.EXTREME, BoosterProfileType.PERFORMANCE -> "Enhanced sensitivity"
    else -> "Standard"
}

private fun batteryModeFor(profile: BoosterProfileType) = when (profile) {
    BoosterProfileType.BATTERY_SAVER -> "Maximum savings"
    BoosterProfileType.EXTREME -> "Performance priority"
    else -> "Balanced"
}
