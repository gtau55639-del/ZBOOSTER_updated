# ZBOOSTER — Persiapan Submit ke Google Play Console

Dokumen ini isinya jawaban siap-tempel untuk form-form di Play Console yang
sering bikin app ditolak kalau dijawab asal. Tinggal copy-paste, sesuaikan
seperlunya, dan lampirkan ke masing-masing bagian di Play Console.

---

## 1. Declaration Form — Justifikasi Permission Sensitif

Play Console akan meminta justifikasi tertulis untuk beberapa permission ini.
**QUERY_ALL_PACKAGES** adalah yang PALING SERING bikin app ditolak kalau
justifikasinya lemah — Google sangat ketat soal ini sejak 2021.

### ✅ `QUERY_ALL_PACKAGES` — SUDAH DIHAPUS dari app

Update: kode sudah diubah supaya app **tidak lagi minta permission ini sama
sekali**. Sebagai gantinya, app pakai `<queries>` bertarget di manifest
(hanya bisa "lihat" app yang punya launcher icon — cukup untuk deteksi
game, tapi jauh lebih aman di mata Google Play karena bukan akses
"semua package"). Ini menghilangkan risiko penolakan terbesar untuk app
kategori ini. Tidak perlu isi form justifikasi untuk permission ini lagi.

### `SYSTEM_ALERT_WINDOW` (Display over other apps)
> **Justifikasi:** "Used only for the optional in-game floating performance
> overlay (FPS/RAM/battery display) that the user must explicitly enable in
> Settings. The app never draws this overlay without the user first granting
> the permission and turning the feature on."

### ✅ `BIND_NOTIFICATION_LISTENER_SERVICE` — SUDAH DIHAPUS dari app

Fitur "Block Notifications While Gaming" dihapus karena permission ini
membuat Google Play Protect menampilkan warning paling parah saat sideload
("dapat meminta akses ke data sensitif... risiko pencurian identitas/
penipuan keuangan") — jauh lebih menakutkan dibanding warning app lain yang
tidak minta akses baca-notifikasi. Tidak perlu isi form justifikasi untuk
permission ini lagi.

### `FOREGROUND_SERVICE` / `FOREGROUND_SERVICE_SPECIAL_USE`
> **Justifikasi:** "Keeps the live Performance Monitor overlay running
> reliably while visible on-screen during gameplay, per Android's background
> execution limits. The foreground service starts only while the monitor is
> visible and stops immediately when the user closes it."

### `POST_NOTIFICATIONS`
> **Justifikasi:** "Displays the persistent 'Boost/Monitor active' status
> notification required by Android 13+ for any active foreground service."

---

## 2. Data Safety Section (Play Console → App content → Data safety)

Jawaban jujur berdasarkan kode yang ada sekarang (app ini TIDAK kirim data
ke server manapun — semuanya lokal di device):

| Pertanyaan | Jawaban |
|---|---|
| Does your app collect or share any of the required user data types? | **No** — semua data (RAM usage, daftar game, profil booster) diproses & disimpan lokal di device, tidak dikirim ke server manapun |
| Is all user data encrypted in transit? | N/A — tidak ada transmisi data ke luar device |
| Do you provide a way for users to request data deletion? | N/A, atau isi "User can clear app data via Android Settings" |
| Data types: "App info and performance" | Kalau app pakai crash reporting (Firebase Crashlytics dsb) di masa depan — **wajib dideklarasikan**. Kalau belum pakai, jawab No. |

> Kalau nanti kamu tambahkan Analytics/Crashlytics/Ads SDK, dokumen ini WAJIB
> diupdate — Google rutin audit kecocokan Data Safety form vs SDK yang
> benar-benar ada di APK.

---

## 3. Privacy Policy

Play Console **mewajibkan** URL Privacy Policy yang bisa diakses publik,
walau app tidak kirim data kemana-mana. Kamu perlu:
1. Buat halaman privacy policy sederhana (bisa pakai Google Sites gratis,
   atau halaman statis di GitHub Pages)
2. Isinya minimal: data apa yang diproses (device RAM, daftar app lokal),
   bahwa semuanya diproses on-device dan tidak dikirim ke server, kontak
   email developer
3. Masukkan URL-nya ke Play Console → App content → Privacy Policy

Saya bisa bantu buatkan draft teks privacy policy-nya kalau mau — tinggal bilang.

---

## 4. Rekomendasi Sebelum Submit (biar peluang approve lebih tinggi)

- [x] ~~Ganti `QUERY_ALL_PACKAGES` jadi `<queries>` bertarget~~ — **sudah dilakukan**
- [ ] Screenshot app (minimal 2, format sesuai device Phone/Tablet) disiapkan
- [ ] Feature graphic (1024×500) & ikon app 512×512 disiapkan
- [ ] Isi "App content" → Content rating questionnaire
- [ ] Isi Target Audience (pilih usia yang sesuai)
- [ ] Build **App Bundle (.aab)**, bukan APK, untuk upload ke Play Console
      (`./gradlew bundleRelease`)
- [ ] Test build release (signed) di device asli dulu sebelum upload

---

## 5. Kenapa Peringatan "Aplikasi diblokir" Play Protect Hilang Otomatis

Begitu app sudah live di Play Store dan disign lewat **Play App Signing**,
Play Protect akan otomatis mempercayai app itu untuk SEMUA user yang
download dari Play Store — peringatan sideload yang kamu lihat selama ini
tidak akan muncul lagi untuk user yang install dari Play Store resmi.
