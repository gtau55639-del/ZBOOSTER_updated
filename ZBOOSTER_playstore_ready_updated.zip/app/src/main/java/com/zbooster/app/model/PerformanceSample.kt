package com.zbooster.app.model

/**
 * A single point-in-time performance reading. Every field is either backed
 * by a real Android API or explicitly null (spec #8/#18: never fabricate
 * numbers, show "not available" instead).
 */
data class PerformanceSample(
    val timestampMs: Long,
    val ramUsagePercent: Int,          // real: ActivityManager.MemoryInfo
    val batteryPercent: Int,           // real: BatteryManager
    val cpuUsagePercent: Int?,         // null: no public universal API without root
    val temperatureCelsius: Float?,    // real if BatteryManager exposes it; else null
    val networkType: String,           // real: ConnectivityManager (Wi-Fi / Mobile / Offline)
    val fpsAvailable: Boolean = false, // true only if a legitimate FPS source exists
    val fps: Int? = null,
    val pingMs: Int? = null            // real: measured TCP round-trip, null if offline/unreachable
)

enum class MonitorGraphMode { LIVE, SIMPLE, DETAILED }

/**
 * Buckets a real ping reading (ms) into a HUD-friendly quality tier.
 * Thresholds are the commonly used gaming-latency bands
 * (competitive-shooter-safe / playable / laggy / unplayable).
 * Returns [UNAVAILABLE] only when [pingMs] is null (never fabricated).
 */
enum class PingQuality { EXCELLENT, GOOD, FAIR, POOR, UNAVAILABLE }

fun pingQualityFor(pingMs: Int?): PingQuality = when {
    pingMs == null -> PingQuality.UNAVAILABLE
    pingMs < 40 -> PingQuality.EXCELLENT
    pingMs < 80 -> PingQuality.GOOD
    pingMs < 150 -> PingQuality.FAIR
    else -> PingQuality.POOR
}
