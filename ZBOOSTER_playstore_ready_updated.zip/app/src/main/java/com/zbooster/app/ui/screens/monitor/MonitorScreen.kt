@file:OptIn(ExperimentalMaterial3Api::class)

package com.zbooster.app.ui.screens.monitor

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zbooster.app.model.MonitorGraphMode
import com.zbooster.app.model.PerformanceSample
import com.zbooster.app.model.PingQuality
import com.zbooster.app.model.pingQualityFor
import com.zbooster.app.ui.components.ZCard
import com.zbooster.app.ui.theme.*

/**
 * Performance Monitor — redesigned as a full-bleed gaming HUD (spec update:
 * "make the ping test more intense, full HD, ROG / RedMagic themed").
 *
 * Reuses ZBOOSTER's existing red/cyber-blue/purple identity (Color.kt) —
 * no new palette — just applied at full intensity: an edge-to-edge dark
 * gradient backdrop with a diagonal accent stripe (the ROG/RedMagic visual
 * signature), a glowing hero ping gauge, and a stat-tile grid instead of a
 * half-empty stacked list. All glow/pulse animation is gated behind
 * [ZUiCapability.allowRichAnimation] so Low-End/Reduce-Animation devices
 * still get the same information with zero animation cost (spec #11).
 */
@Composable
fun MonitorScreen(viewModel: MonitorViewModel = viewModel()) {
    val isLive by viewModel.isLive.collectAsStateWithLifecycle()
    val graphMode by viewModel.graphMode.collectAsStateWithLifecycle()
    val latest by viewModel.latest.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    val uiCapability = LocalZUiCapability.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(hudBackdropBrush())
    ) {
        HudDiagonalStripe(allowRichAnimation = uiCapability.allowRichAnimation)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { MonitorHudHeader(isLive = isLive, onToggle = viewModel::toggleLive) }

            item { GraphModeSelector(selected = graphMode, onSelect = viewModel::setGraphMode) }

            item {
                PingHero(
                    pingMs = latest?.pingMs,
                    isLive = isLive,
                    allowRichAnimation = uiCapability.allowRichAnimation
                )
            }

            item {
                when {
                    !isLive -> HudIdleCard()
                    latest == null -> HudLoadingCard()
                    else -> StatTileGrid(sample = latest!!, detailed = graphMode == MonitorGraphMode.DETAILED)
                }
            }

            if (isLive && graphMode != MonitorGraphMode.SIMPLE && history.size > 1) {
                item { RamHistoryChart(history) }
            }

            // Spacer so the HUD content breathes to the bottom of the
            // screen instead of stopping halfway up (the "setengah-setengah"
            // half-filled look this redesign replaces).
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

/** Edge-to-edge dark gradient, near-black base fading into a faint red/purple glow at the corners. */
private fun hudBackdropBrush(): Brush = Brush.radialGradient(
    colors = listOf(
        ZSurfaceElevated.copy(alpha = 0.9f),
        ZBackground,
        Color.Black
    ),
    radius = 1400f
)

/**
 * The single-diagonal-cut accent stripe that reads instantly as
 * ROG/RedMagic-style gamer hardware — a thin, glowing red band cutting
 * across the top of the screen behind the header. Pure decoration drawn
 * once with Canvas (cheap on low-end devices); the glow layer only
 * animates when rich animation is allowed.
 */
@Composable
private fun HudDiagonalStripe(allowRichAnimation: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "hudStripeGlow")
    val glowAlpha by if (allowRichAnimation) {
        infiniteTransition.animateFloat(
            initialValue = 0.25f,
            targetValue = 0.55f,
            animationSpec = infiniteRepeatable(
                animation = tween(1800, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "hudStripeAlpha"
        )
    } else {
        remember { mutableStateOf(0.4f) }
    }

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
    ) {
        val stripeColor = ZElectricRed.copy(alpha = glowAlpha)
        val accentColor = ZCyberBlue.copy(alpha = glowAlpha * 0.6f)
        drawLine(
            color = stripeColor,
            start = Offset(size.width * 0.15f, 0f),
            end = Offset(size.width * 0.55f, size.height),
            strokeWidth = 3f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = accentColor,
            start = Offset(size.width * 0.28f, 0f),
            end = Offset(size.width * 0.68f, size.height),
            strokeWidth = 2f,
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun MonitorHudHeader(isLive: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                "PERFORMANCE MONITOR",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black,
                color = ZTextPrimary
            )
            Text(
                "Live ping test & device HUD",
                style = MaterialTheme.typography.bodyMedium,
                color = ZTextSecondary
            )
        }
        Button(
            onClick = onToggle,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isLive) ZSurfaceElevated else ZElectricRed
            )
        ) {
            Icon(if (isLive) Icons.Filled.Stop else Icons.Filled.PlayArrow, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text(if (isLive) "STOP" else "START", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun GraphModeSelector(selected: MonitorGraphMode, onSelect: (MonitorGraphMode) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MonitorGraphMode.entries.forEach { mode ->
            FilterChip(
                selected = selected == mode,
                onClick = { onSelect(mode) },
                label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = ZElectricRed.copy(alpha = 0.25f),
                    selectedLabelColor = ZTextPrimary
                )
            )
        }
    }
}

/**
 * The centerpiece "ping test" gauge — a large glowing ring around the
 * live latency number, color-coded by [PingQuality]. This is the main
 * visual the user asked to make "more intense": full-width, large type,
 * animated glow ring while live and connected.
 */
@Composable
private fun PingHero(pingMs: Int?, isLive: Boolean, allowRichAnimation: Boolean) {
    val quality = pingQualityFor(pingMs)
    val ringColor = quality.hudColor()

    val infiniteTransition = rememberInfiniteTransition(label = "pingRingPulse")
    val ringGlow by if (allowRichAnimation && isLive && pingMs != null) {
        infiniteTransition.animateFloat(
            initialValue = 0.5f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(1100, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pingRingGlow"
        )
    } else {
        remember { mutableStateOf(0.75f) }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(
                Brush.verticalGradient(
                    listOf(ZSurfaceElevated, ZSurface)
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 28.dp, horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Wifi, contentDescription = null, tint = ZTextSecondary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    "PING TEST",
                    style = MaterialTheme.typography.labelLarge,
                    color = ZTextSecondary
                )
            }

            Spacer(Modifier.height(18.dp))

            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(180.dp)) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokeWidth = 10.dp.toPx()
                    // Base track
                    drawCircle(
                        color = ZSurfaceBorder,
                        style = Stroke(width = strokeWidth)
                    )
                    // Glowing progress ring — full circle when we have a real
                    // reading, faint/static when unavailable or not live.
                    drawCircle(
                        color = ringColor.copy(alpha = if (pingMs != null) ringGlow else 0.25f),
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = pingMs?.toString() ?: "--",
                        style = MaterialTheme.typography.displayLarge,
                        fontWeight = FontWeight.Black,
                        color = ZTextPrimary
                    )
                    Text(
                        text = if (pingMs != null) "ms" else "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ZTextSecondary
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            Surface(
                shape = RoundedCornerShape(50),
                color = ringColor.copy(alpha = 0.16f)
            ) {
                Text(
                    text = quality.label(isLive),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    style = MaterialTheme.typography.labelLarge,
                    color = ringColor,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private fun PingQuality.hudColor(): Color = when (this) {
    PingQuality.EXCELLENT -> ZSuccess
    PingQuality.GOOD -> ZCyberBlue
    PingQuality.FAIR -> ZWarning
    PingQuality.POOR -> ZElectricRed
    PingQuality.UNAVAILABLE -> ZTextDisabled
}

private fun PingQuality.label(isLive: Boolean): String = when {
    !isLive -> "MONITOR OFF"
    this == PingQuality.UNAVAILABLE -> "NO CONNECTION"
    this == PingQuality.EXCELLENT -> "EXCELLENT · COMPETITIVE READY"
    this == PingQuality.GOOD -> "GOOD · SMOOTH ONLINE PLAY"
    this == PingQuality.FAIR -> "FAIR · NOTICEABLE LAG"
    else -> "POOR · HIGH LATENCY"
}

@Composable
private fun HudIdleCard() {
    ZCard {
        Text(
            "Monitoring is off to save battery. Tap Start to begin live tracking and run the ping test.",
            modifier = Modifier.padding(16.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = ZTextSecondary
        )
    }
}

@Composable
private fun HudLoadingCard() {
    ZCard {
        Box(Modifier.padding(24.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = ZElectricRed)
        }
    }
}

/** Full-width 2-column grid of stat tiles — replaces the old stacked list so the HUD fills the screen. */
@Composable
private fun StatTileGrid(sample: PerformanceSample, detailed: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            StatTile("RAM USAGE", "${sample.ramUsagePercent}%", ZCyberBlue, Modifier.weight(1f))
            StatTile("BATTERY", "${sample.batteryPercent}%", ZSuccess, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            StatTile(
                "CPU USAGE",
                sample.cpuUsagePercent?.let { "$it%" } ?: "N/A",
                ZPurpleAccent,
                Modifier.weight(1f)
            )
            StatTile(
                "TEMPERATURE",
                sample.temperatureCelsius?.let { "${it}°C" } ?: "N/A",
                ZWarning,
                Modifier.weight(1f)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            StatTile("NETWORK", sample.networkType, ZElectricRed, Modifier.weight(1f))
            if (detailed) {
                StatTile(
                    "FPS",
                    if (sample.fpsAvailable) "${sample.fps}" else "N/A",
                    ZCyberBlue,
                    Modifier.weight(1f)
                )
            } else {
                Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = ZSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = 0.35f))
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = ZTextSecondary)
            Spacer(Modifier.height(4.dp))
            Text(
                value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = accent
            )
        }
    }
}

/**
 * Deliberately simple line chart drawn with Canvas — no external charting
 * library — to keep the app light on low-end devices (spec #11/#8).
 */
@Composable
private fun RamHistoryChart(history: List<PerformanceSample>) {
    ZCard {
        Column(Modifier.padding(16.dp)) {
            Text("RAM Usage (last ${history.size} samples)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                if (history.size < 2) return@Canvas
                val maxVal = 100f
                val stepX = size.width / (history.size - 1)
                val points = history.mapIndexed { index, sample ->
                    Offset(
                        x = index * stepX,
                        y = size.height - (sample.ramUsagePercent / maxVal) * size.height
                    )
                }
                for (i in 0 until points.size - 1) {
                    drawLine(
                        color = ZCyberBlue,
                        start = points[i],
                        end = points[i + 1],
                        strokeWidth = 4f,
                        cap = StrokeCap.Round
                    )
                }
            }
        }
    }
}
