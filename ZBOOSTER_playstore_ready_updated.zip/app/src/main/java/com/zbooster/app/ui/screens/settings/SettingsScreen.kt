package com.zbooster.app.ui.screens.settings

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zbooster.app.ui.components.ZCard
import com.zbooster.app.ui.components.ZSettingsSectionHeader
import com.zbooster.app.ui.components.ZSwitchRow
import com.zbooster.app.ui.components.ZNavigationRow
import com.zbooster.app.ui.components.ZPickerRow
import com.zbooster.app.ui.theme.ZPerformanceMode
import com.zbooster.app.ui.theme.ZThemeMode
import com.zbooster.app.util.PermissionHelper

private enum class ZSpecialPermission { DND, OVERLAY }

@Composable
fun SettingsScreen(
    onOpenAbout: () -> Unit = {},
    viewModel: SettingsViewModel = viewModel()
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val performanceMode by viewModel.performanceMode.collectAsStateWithLifecycle()
    val reduceAnimation by viewModel.reduceAnimation.collectAsStateWithLifecycle()
    val autoGameMode by viewModel.autoGameMode.collectAsStateWithLifecycle()
    val dndEnabledStored by viewModel.dndEnabled.collectAsStateWithLifecycle()
    val overlayEnabledStored by viewModel.overlayEnabled.collectAsStateWithLifecycle()
    val keepScreenOn by viewModel.keepScreenOn.collectAsStateWithLifecycle()
    val landscapeFullscreen by viewModel.landscapeFullscreen.collectAsStateWithLifecycle()

    var showResetConfirm by remember { mutableStateOf(false) }
    var pendingPermission by remember { mutableStateOf<ZSpecialPermission?>(null) }

    // Real, live-checked system permission state — never trusted from
    // DataStore alone, since the user can revoke any of these from
    // system Settings at any time without ZBOOSTER knowing.
    var dndGranted by remember { mutableStateOf(PermissionHelper.hasDndAccess(context)) }
    var overlayGranted by remember { mutableStateOf(PermissionHelper.hasOverlayPermission(context)) }

    // Re-check real permission state whenever the screen resumes (e.g. the
    // user comes back from a system Settings screen), and self-heal the
    // stored toggle if the underlying permission was revoked outside the app.
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                dndGranted = PermissionHelper.hasDndAccess(context)
                overlayGranted = PermissionHelper.hasOverlayPermission(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(dndEnabledStored, dndGranted) {
        if (dndEnabledStored && !dndGranted) viewModel.setDndEnabled(false)
    }
    LaunchedEffect(overlayEnabledStored, overlayGranted) {
        if (overlayEnabledStored && !overlayGranted) viewModel.setOverlayEnabled(false)
    }

    val dndEnabled = dndEnabledStored && dndGranted
    val overlayEnabled = overlayEnabledStored && overlayGranted

    // Game Overlay: start/stop the real floating panel service to match
    // the effective (stored AND permission-granted) state — covers both
    // toggling the switch and reopening the app with the setting already on.
    LaunchedEffect(overlayEnabled) {
        val intent = Intent(context, com.zbooster.app.service.GameOverlayService::class.java)
        if (overlayEnabled) {
            context.startService(intent)
        } else {
            context.stopService(intent)
        }
    }

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Text(
                "Settings",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(16.dp)
            )
        }

        // GENERAL
        item { ZSettingsSectionHeader("General") }
        item {
            ZCard {
                Column {
                    ZSwitchRow(
                        title = "Auto Game Mode",
                        subtitle = "Automatically apply boost profile when a game launches",
                        checked = autoGameMode,
                        onCheckedChange = viewModel::setAutoGameMode
                    )
                }
            }
        }

        // THEME
        item { ZSettingsSectionHeader("Theme") }
        item {
            ZCard {
                ZPickerRow(
                    title = "App Theme",
                    options = listOf(
                        ZThemeMode.DARK to "Dark",
                        ZThemeMode.AMOLED to "AMOLED",
                        ZThemeMode.LIGHT to "Light"
                    ),
                    selected = themeMode,
                    onSelected = viewModel::setThemeMode
                )
            }
        }

        // PERFORMANCE
        item { ZSettingsSectionHeader("Performance") }
        item {
            ZCard {
                ZPickerRow(
                    title = "Performance Mode",
                    options = listOf(
                        ZPerformanceMode.AUTO to "Auto",
                        ZPerformanceMode.LOW_END to "Low-End",
                        ZPerformanceMode.BALANCED to "Balanced",
                        ZPerformanceMode.HIGH_END to "High-End"
                    ),
                    selected = performanceMode,
                    onSelected = viewModel::setPerformanceMode
                )
            }
        }

        // ANIMATION
        item { ZSettingsSectionHeader("Animation") }
        item {
            ZCard {
                ZSwitchRow(
                    title = "Reduce Animation",
                    subtitle = "Disable non-essential motion effects",
                    checked = reduceAnimation,
                    onCheckedChange = viewModel::setReduceAnimation
                )
            }
        }

        // GAMEPLAY / DND / OVERLAY
        item { ZSettingsSectionHeader("Gameplay") }
        item {
            ZCard {
                Column {
                    ZSwitchRow(
                        title = "Do Not Disturb",
                        subtitle = if (dndEnabledStored && !dndGranted)
                            "Access was revoked in system Settings — tap to re-grant"
                        else "Silence notifications during gaming (requires DND access)",
                        checked = dndEnabled,
                        onCheckedChange = { turnOn ->
                            if (!turnOn) {
                                viewModel.setDndEnabled(false)
                            } else if (dndGranted) {
                                viewModel.setDndEnabled(true)
                            } else {
                                pendingPermission = ZSpecialPermission.DND
                            }
                        }
                    )
                    HorizontalDivider()
                    ZSwitchRow(
                        title = "Keep Screen On",
                        subtitle = "Prevent the screen from sleeping while gaming",
                        checked = keepScreenOn,
                        onCheckedChange = viewModel::setKeepScreenOn
                    )
                    HorizontalDivider()
                    ZSwitchRow(
                        title = "Landscape + Fullscreen",
                        subtitle = "Lock the app to landscape and hide the status/navigation bars",
                        checked = landscapeFullscreen,
                        onCheckedChange = viewModel::setLandscapeFullscreen
                    )
                    HorizontalDivider()
                    ZSwitchRow(
                        title = "Game Overlay",
                        subtitle = if (overlayEnabledStored && !overlayGranted)
                            "Access was revoked in system Settings — tap to re-grant"
                        else "Floating quick-access panel during gameplay (requires Display over other apps)",
                        checked = overlayEnabled,
                        onCheckedChange = { turnOn ->
                            if (!turnOn) {
                                viewModel.setOverlayEnabled(false)
                            } else if (overlayGranted) {
                                viewModel.setOverlayEnabled(true)
                            } else {
                                pendingPermission = ZSpecialPermission.OVERLAY
                            }
                        }
                    )
                }
            }
        }

        // PERMISSIONS
        item { ZSettingsSectionHeader("Permissions") }
        item {
            ZCard {
                ZNavigationRow(
                    title = "App Permissions",
                    subtitle = "Review what ZBOOSTER can access",
                    onClick = {
                        val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = android.net.Uri.fromParts("package", context.packageName, null)
                        }
                        context.startActivity(intent)
                    }
                )
            }
        }

        // ABOUT
        item { ZSettingsSectionHeader("About") }
        item {
            ZCard {
                ZNavigationRow(title = "About ZBOOSTER", subtitle = "Version, privacy policy, licenses", onClick = onOpenAbout)
            }
        }

        item { ZSettingsSectionHeader("Reset") }
        item {
            ZCard {
                ZNavigationRow(
                    title = "Reset Settings",
                    subtitle = "Restore all ZBOOSTER settings to their defaults",
                    onClick = { showResetConfirm = true }
                )
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("Reset Settings?") },
            text = { Text("This will restore all ZBOOSTER settings to their defaults. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.resetAll()
                    showResetConfirm = false
                }) { Text("Reset") }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) { Text("Cancel") }
            }
        )
    }

    pendingPermission?.let { permission ->
        val (title, message, intent) = when (permission) {
            ZSpecialPermission.DND -> Triple(
                "Allow Do Not Disturb access?",
                "ZBOOSTER needs Do Not Disturb access to silence notifications while you game. " +
                    "You'll be taken to a system screen — find ZBOOSTER in the list and turn it on.",
                PermissionHelper.dndSettingsIntent()
            )
            ZSpecialPermission.OVERLAY -> Triple(
                "Allow display over other apps?",
                "ZBOOSTER needs this permission to draw the floating Game Overlay on top of your games. " +
                    "You'll be taken to a system screen to grant it.",
                PermissionHelper.overlaySettingsIntent(context)
            )
        }
        AlertDialog(
            onDismissRequest = { pendingPermission = null },
            title = { Text(title) },
            text = { Text(message) },
            confirmButton = {
                TextButton(onClick = {
                    pendingPermission = null
                    context.startActivity(intent)
                }) { Text("Continue") }
            },
            dismissButton = {
                TextButton(onClick = { pendingPermission = null }) { Text("Not now") }
            }
        )
    }
}


