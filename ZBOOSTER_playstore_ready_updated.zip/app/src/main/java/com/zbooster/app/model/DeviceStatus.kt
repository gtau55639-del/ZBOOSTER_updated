package com.zbooster.app.model

/**
 * Honest snapshot of device status. Any field Android cannot legitimately
 * report is left null and the UI shows "Not available" rather than a
 * fabricated number (spec #8 / #18 — no fake data, ever).
 */
data class DeviceStatus(
    val cpuUsagePercent: Int?,      // best-effort, may be null on some OEMs/API levels
    val ramUsagePercent: Int,       // always available via ActivityManager
    val batteryPercent: Int,        // always available via BatteryManager
    val temperatureCelsius: Float?, // null if system does not expose it
    val isCharging: Boolean,
    val storageTotalBytes: Long = 0L,  // always available via StatFs
    val storageFreeBytes: Long = 0L    // always available via StatFs
) {
    val isGamingReady: Boolean
        get() = ramUsagePercent < 90 && batteryPercent > 15

    val storageUsagePercent: Int
        get() {
            if (storageTotalBytes <= 0) return 0
            return (((storageTotalBytes - storageFreeBytes) * 100) / storageTotalBytes).toInt().coerceIn(0, 100)
        }
}
