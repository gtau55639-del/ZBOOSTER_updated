package com.zbooster.app.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.zbooster.app.ui.screens.boost.BoostScreen
import com.zbooster.app.ui.screens.gamedetail.GameDetailScreen
import com.zbooster.app.ui.screens.games.GamesScreen
import com.zbooster.app.ui.screens.home.HomeScreen
import com.zbooster.app.ui.screens.monitor.MonitorScreen
import com.zbooster.app.ui.screens.settings.AboutScreen
import com.zbooster.app.ui.screens.settings.SettingsScreen
import com.zbooster.app.ui.theme.LocalZUiCapability
import com.zbooster.app.ui.theme.ZWindowSize

@Composable
fun ZNavHost(windowSize: ZWindowSize) {
    val navController = rememberNavController()
    val uiCapability = LocalZUiCapability.current

    // Soft fade + slide transition between top-level screens (bottom-nav
    // tabs, and pushed screens like Game Detail / About). Falls back to an
    // instant switch (no animation) when Reduce Animation / Low-End mode is
    // active, matching the rest of the app's animateRich gating.
    val transitionMs = if (uiCapability.allowRichAnimation) 220 else 0
    val enter = fadeIn(tween(transitionMs)) + slideInHorizontally(tween(transitionMs)) { it / 12 }
    val exit = fadeOut(tween(transitionMs)) + slideOutHorizontally(tween(transitionMs)) { -it / 12 }
    val popEnter = fadeIn(tween(transitionMs)) + slideInHorizontally(tween(transitionMs)) { -it / 12 }
    val popExit = fadeOut(tween(transitionMs)) + slideOutHorizontally(tween(transitionMs)) { it / 12 }

    Scaffold(
        bottomBar = {
            // On large/tablet layouts a rail could replace this bottom bar;
            // kept as bottom nav for all sizes for now per spec STEP 13.
            ZBottomNavBar(navController)
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = ZDestination.Home.route,
            modifier = Modifier.padding(innerPadding),
            enterTransition = { enter },
            exitTransition = { exit },
            popEnterTransition = { popEnter },
            popExitTransition = { popExit }
        ) {
            composable(ZDestination.Home.route) {
                HomeScreen(
                    windowSize = windowSize,
                    onOpenSettings = { navController.navigate(ZDestination.Settings.route) },
                    onGoToBoostProfiles = { navController.navigate(ZDestination.Boost.route) }
                )
            }
            composable(ZDestination.Games.route) {
                GamesScreen(
                    windowSize = windowSize,
                    onGameClick = { gameId -> navController.navigate(gameDetailRoute(gameId)) }
                )
            }
            composable(
                route = ROUTE_GAME_DETAIL,
                arguments = listOf(navArgument("gameId") { type = NavType.StringType })
            ) { backStackEntry ->
                val gameId = backStackEntry.arguments?.getString("gameId").orEmpty()
                GameDetailScreen(
                    packageName = gameId,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(ZDestination.Boost.route) { BoostScreen() }
            composable(ZDestination.Monitor.route) { MonitorScreen() }
            composable(ZDestination.Settings.route) {
                SettingsScreen(onOpenAbout = { navController.navigate(ROUTE_ABOUT) })
            }
            composable(ROUTE_ABOUT) {
                AboutScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}

@Composable
private fun ZBottomNavBar(navController: NavHostController) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    NavigationBar {
        ZDestination.bottomNavItems.forEach { destination ->
            NavigationBarItem(
                selected = currentRoute == destination.route,
                onClick = {
                    navController.navigate(destination.route) {
                        popUpTo(navController.graph.findStartDestination().id) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { Icon(destination.icon, contentDescription = stringResource(destination.labelRes)) },
                label = { Text(stringResource(destination.labelRes)) }
            )
        }
    }
}
