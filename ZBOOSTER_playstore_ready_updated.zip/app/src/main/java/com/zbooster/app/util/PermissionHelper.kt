package com.zbooster.app.util

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

/**
 * Single source of truth for the "special" runtime permissions ZBOOSTER
 * uses. Each check reflects the REAL current system state (never a cached
 * DataStore boolean), and each settings-intent helper points to the exact
 * system screen the user needs, per spec's "never assume it is granted"
 * rule.
 */
object PermissionHelper {

    /** Do Not Disturb / notification policy access (Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS). */
    fun hasDndAccess(context: Context): Boolean {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        return manager?.isNotificationPolicyAccessGranted == true
    }

    fun dndSettingsIntent(): Intent =
        Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)

    /** "Display over other apps" for the floating Game Overlay. */
    fun hasOverlayPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    fun overlaySettingsIntent(context: Context): Intent =
        Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        )
}
