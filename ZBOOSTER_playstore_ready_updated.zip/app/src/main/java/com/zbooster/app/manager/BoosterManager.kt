package com.zbooster.app.manager

import android.content.Context
import kotlinx.coroutines.delay

/**
 * Performs ONLY optimizations that Android genuinely allows a normal app to
 * do, per spec #4/#6/#18. Explicitly does NOT:
 *  - free "physical RAM" (impossible without root)
 *  - force-kill other apps on modern Android (not permitted)
 *  - overclock CPU/GPU (not permitted)
 *  - fabricate a temperature drop
 *
 * What it DOES do, honestly:
 *  - clears ZBOOSTER's own cache directory
 *  - cancels/stops ZBOOSTER's own unnecessary background work
 *  - hints the system via System.gc() (advisory only — not guaranteed)
 */
class BoosterManager(private val context: Context) {

    sealed class BoostResult {
        data class Success(val clearedCacheBytes: Long) : BoostResult()
        data class Failure(val reason: String) : BoostResult()
    }

    suspend fun runBoost(): BoostResult {
        return try {
            val cleared = clearOwnCache()
            // Advisory hint only; the JVM/ART decides whether to actually collect.
            System.gc()
            // Small delay purely for a satisfying, honest UI transition —
            // not simulating fake "processing" of other apps. Kept short so
            // Boost Now feels snappy rather than sluggish.
            delay(250)
            BoostResult.Success(cleared)
        } catch (e: Exception) {
            BoostResult.Failure(e.message ?: "Unknown error")
        }
    }

    private fun clearOwnCache(): Long {
        val cacheDir = context.cacheDir ?: return 0L
        var totalCleared = 0L
        cacheDir.listFiles()?.forEach { file ->
            totalCleared += file.length()
            file.deleteRecursively()
        }
        return totalCleared
    }
}
