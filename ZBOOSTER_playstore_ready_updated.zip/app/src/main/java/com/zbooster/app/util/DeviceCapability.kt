package com.zbooster.app.util

import android.app.ActivityManager
import android.content.Context
import com.zbooster.app.ui.theme.ZPerformanceMode

/**
 * Resolves ZPerformanceMode.AUTO into a concrete LOW_END/BALANCED/HIGH_END
 * value based on total device RAM and Android version — all information
 * legitimately available without any special permission.
 *
 * This does NOT read per-app memory, does NOT claim to add RAM, and does
 * NOT report fabricated numbers — it only classifies the device itself
 * so the UI can scale animation/blur/lazy-loading accordingly (spec #11, #18).
 */
object DeviceCapability {

    fun resolveAutoPerformanceMode(context: Context): ZPerformanceMode {
        return classifyRamMb(totalRamMb(context))
    }

    /**
     * Pure RAM->mode classification, split out from [resolveAutoPerformanceMode]
     * so the thresholds themselves are unit-testable without an Android
     * [Context] (no emulator/instrumentation required for this part).
     */
    fun classifyRamMb(totalRamMb: Long): ZPerformanceMode {
        return when {
            totalRamMb in 1..3071 -> ZPerformanceMode.LOW_END
            totalRamMb in 3072..6143 -> ZPerformanceMode.BALANCED
            totalRamMb >= 6144 -> ZPerformanceMode.HIGH_END
            else -> ZPerformanceMode.BALANCED // unknown (<=0) -> safe middle ground
        }
    }

    /** Total physical RAM in MB, as reported by ActivityManager (no root needed). */
    fun totalRamMb(context: Context): Long {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val info = ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            info.totalMem / (1024 * 1024)
        } catch (e: Exception) {
            0L
        }
    }

    /** Currently available RAM in MB — used by the live Performance Monitor. */
    fun availableRamMb(context: Context): Long {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val info = ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            info.availMem / (1024 * 1024)
        } catch (e: Exception) {
            0L
        }
    }

    /** RAM usage percentage (0-100), derived honestly from total/available above. */
    fun ramUsagePercent(context: Context): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return 0
        val info = ActivityManager.MemoryInfo()
        return try {
            am.getMemoryInfo(info)
            if (info.totalMem <= 0) 0
            else (((info.totalMem - info.availMem) * 100) / info.totalMem).toInt().coerceIn(0, 100)
        } catch (e: Exception) {
            0
        }
    }

    /**
     * Real internal-storage totals for the whole device, via [android.os.StatFs]
     * on the data partition — the same API Android's own Settings > Storage
     * page is built on. No permission required, and no distinction is made
     * for "how much ZBOOSTER could free up" (it can't free other apps' data;
     * see [com.zbooster.app.manager.BoosterManager]'s doc comment) — this is
     * purely an honest device-storage readout.
     */
    fun totalStorageBytes(): Long = try {
        val stat = android.os.StatFs(android.os.Environment.getDataDirectory().path)
        stat.totalBytes
    } catch (e: Exception) {
        0L
    }

    fun freeStorageBytes(): Long = try {
        val stat = android.os.StatFs(android.os.Environment.getDataDirectory().path)
        stat.availableBytes
    } catch (e: Exception) {
        0L
    }

    /** Storage used percentage (0-100), derived from the two reads above. */
    fun storageUsagePercent(): Int {
        val total = totalStorageBytes()
        val free = freeStorageBytes()
        return if (total <= 0) 0
        else (((total - free) * 100) / total).toInt().coerceIn(0, 100)
    }
}
