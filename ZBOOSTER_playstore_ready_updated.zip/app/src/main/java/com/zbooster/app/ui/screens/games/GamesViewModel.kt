package com.zbooster.app.ui.screens.games

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zbooster.app.model.Game
import com.zbooster.app.model.GameCategory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class GamesLoadState { LOADING, LOADED, EMPTY, PERMISSION_LIMITED }

class GamesViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as com.zbooster.app.ZBoosterApplication).gameRepository

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow(GameCategory.ALL)
    val selectedCategory: StateFlow<GameCategory> = _selectedCategory.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    // Bumping this value re-runs the PackageManager scan inside
    // repository.observeGames(), giving "Refresh Game List" real effect.
    private val refreshTrigger = MutableStateFlow(0)

    private val allGames: StateFlow<List<Game>> = repository.observeGames(refreshTrigger)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredGames: StateFlow<List<Game>> = combine(
        allGames, _searchQuery, _selectedCategory
    ) { games, query, category ->
        games
            .filter { game ->
                category == GameCategory.ALL ||
                    (category == GameCategory.FAVORITE && game.isFavorite) ||
                    (category == GameCategory.RECENTLY_PLAYED && game.lastPlayedTimestamp != null) ||
                    (category == GameCategory.HIGH_PERFORMANCE && game.boosterProfile.name in setOf("PERFORMANCE", "EXTREME")) ||
                    (category == GameCategory.CUSTOM && game.boosterProfile.name == "CUSTOM")
            }
            .filter { it.appName.contains(query, ignoreCase = true) }
            .let { list ->
                if (category == GameCategory.RECENTLY_PLAYED) {
                    list.sortedByDescending { it.lastPlayedTimestamp ?: 0L }
                } else {
                    list.sortedBy { it.appName.lowercase() }
                }
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val loadState: StateFlow<GamesLoadState> = combine(allGames, _isRefreshing) { games, refreshing ->
        when {
            refreshing -> GamesLoadState.LOADING
            games.isEmpty() -> GamesLoadState.EMPTY
            else -> GamesLoadState.LOADED
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), GamesLoadState.LOADING)

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun onCategorySelected(category: GameCategory) {
        _selectedCategory.value = category
    }

    fun refresh() {
        viewModelScope.launch {
            _isRefreshing.value = true
            refreshTrigger.value += 1
            kotlinx.coroutines.delay(150) // brief, honest UI feedback for the scan
            _isRefreshing.value = false
        }
    }

    fun addToZBooster(packageName: String) {
        viewModelScope.launch { repository.addToZBooster(packageName) }
    }

    fun removeFromZBooster(packageName: String) {
        viewModelScope.launch { repository.removeFromZBooster(packageName) }
    }

    fun toggleFavorite(packageName: String, isFavorite: Boolean) {
        viewModelScope.launch { repository.toggleFavorite(packageName, isFavorite) }
    }
}
