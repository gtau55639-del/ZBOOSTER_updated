package com.zbooster.app.ui.screens.home

import android.app.Application
import android.os.BatteryManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zbooster.app.manager.BoosterManager
import com.zbooster.app.model.DeviceStatus
import com.zbooster.app.util.DeviceCapability
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class BoostUiState { IDLE, BOOSTING, COMPLETE }

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val boosterManager = BoosterManager(application)

    private val _deviceStatus = MutableStateFlow(readDeviceStatus())
    val deviceStatus: StateFlow<DeviceStatus> = _deviceStatus.asStateFlow()

    private val _boostState = MutableStateFlow(BoostUiState.IDLE)
    val boostState: StateFlow<BoostUiState> = _boostState.asStateFlow()

    private val _lastClearedBytes = MutableStateFlow(0L)
    val lastClearedBytes: StateFlow<Long> = _lastClearedBytes.asStateFlow()

    fun refreshStatus() {
        _deviceStatus.value = readDeviceStatus()
    }

    fun onBoostNow() {
        if (_boostState.value == BoostUiState.BOOSTING) return
        viewModelScope.launch {
            _boostState.value = BoostUiState.BOOSTING
            when (val result = boosterManager.runBoost()) {
                is BoosterManager.BoostResult.Success -> {
                    _lastClearedBytes.value = result.clearedCacheBytes
                    _boostState.value = BoostUiState.COMPLETE
                }
                is BoosterManager.BoostResult.Failure -> {
                    _boostState.value = BoostUiState.IDLE
                }
            }
            refreshStatus()
        }
    }

    fun acknowledgeBoostComplete() {
        _boostState.value = BoostUiState.IDLE
    }

    private fun readDeviceStatus(): DeviceStatus {
        val app = getApplication<Application>()
        val ramUsage = DeviceCapability.ramUsagePercent(app)
        val batteryManager = app.getSystemService(Application.BATTERY_SERVICE) as? BatteryManager
        val batteryPercent = batteryManager
            ?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            ?.takeIf { it in 0..100 } ?: 0
        val isCharging = batteryManager
            ?.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS) ==
            android.os.BatteryManager.BATTERY_STATUS_CHARGING

        return DeviceStatus(
            // Android exposes no public, reliable per-core CPU usage API for
            // regular apps without root — honestly report as unavailable
            // rather than faking a number (spec #8/#18).
            cpuUsagePercent = null,
            ramUsagePercent = ramUsage,
            batteryPercent = batteryPercent,
            temperatureCelsius = null,
            isCharging = isCharging,
            storageTotalBytes = DeviceCapability.totalStorageBytes(),
            storageFreeBytes = DeviceCapability.freeStorageBytes()
        )
    }
}
