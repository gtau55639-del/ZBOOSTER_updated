package com.zbooster.app.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Real network latency ("ping test") reader for the Performance Monitor.
 *
 * Android apps cannot send raw ICMP echo requests without root, so — like
 * every non-rooted "ping test" app on Play — this measures round-trip time
 * via a short-lived TCP handshake (SYN → SYN-ACK) to well-known, always-on
 * public hosts. This is a genuine, on-device network measurement, not a
 * fabricated number (spec #8/#18): if every host is unreachable, it
 * reports null ("Offline"/"Unavailable") rather than guessing.
 */
object PingSampler {

    private const val CONNECT_TIMEOUT_MS = 1200
    private const val PORT = 443

    // A short spread of stable, low-latency anycast endpoints (DNS/CDN
    // providers), so one provider's local routing hiccup doesn't skew the
    // whole reading. The lowest successful round-trip is reported, which is
    // standard ping-test practice (closest thing to "true" link latency).
    private val PROBE_HOSTS = listOf(
        "1.1.1.1",        // Cloudflare
        "8.8.8.8",        // Google
        "9.9.9.9"         // Quad9
    )

    suspend fun measure(context: Context): Int? = withContext(Dispatchers.IO) {
        if (!hasActiveConnection(context)) return@withContext null

        val results = PROBE_HOSTS.map { host ->
            async { pingHost(host) }
        }.map { it.await() }

        results.filterNotNull().minOrNull()
    }

    private fun pingHost(host: String): Int? {
        return try {
            val socket = Socket()
            val start = System.nanoTime()
            socket.connect(InetSocketAddress(host, PORT), CONNECT_TIMEOUT_MS)
            val elapsedMs = (System.nanoTime() - start) / 1_000_000
            runCatching { socket.close() }
            elapsedMs.toInt().coerceAtLeast(1)
        } catch (e: Exception) {
            null
        }
    }

    private fun hasActiveConnection(context: Context): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return false
            val network = cm.activeNetwork ?: return false
            val capabilities = cm.getNetworkCapabilities(network) ?: return false
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            false
        }
    }
}
