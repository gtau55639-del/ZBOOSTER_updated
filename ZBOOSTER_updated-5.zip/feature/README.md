# feature/

Reserved for future per-feature Gradle modules (e.g. `:feature:games`,
`:feature:monitor`) if ZBOOSTER is split into multiple modules later.
Currently empty — all code lives in the single `:app` module.
