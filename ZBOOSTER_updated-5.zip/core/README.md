# core/

Reserved for future shared/core Gradle modules (e.g. a `:core:ui` or
`:core:data` module) if ZBOOSTER is split into multiple modules later.
Currently empty — all code lives in the single `:app` module.
