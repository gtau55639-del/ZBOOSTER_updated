# ZBOOSTER Proguard Rules

# Keep Room entities/DAOs
-keep class com.zbooster.app.data.local.** { *; }

# Keep model classes used for DataStore/Room serialization
-keep class com.zbooster.app.model.** { *; }

# Compose
-dontwarn androidx.compose.**
