package com.zbooster.app.ui.screens.boost

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zbooster.app.model.BoosterProfileType
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BoostViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepository = (application as com.zbooster.app.ZBoosterApplication).settingsRepository

    // Reuses the existing performanceMode preference as the "active global
    // profile" concept requested by spec STEP 6, keeping a single source of
    // truth instead of a second, redundant DataStore key.
    val activeProfile: StateFlow<BoosterProfileType> = settingsRepository.performanceMode
        .map { perfMode ->
            when (perfMode) {
                com.zbooster.app.ui.theme.ZPerformanceMode.LOW_END -> BoosterProfileType.BATTERY_SAVER
                com.zbooster.app.ui.theme.ZPerformanceMode.HIGH_END -> BoosterProfileType.PERFORMANCE
                com.zbooster.app.ui.theme.ZPerformanceMode.BALANCED -> BoosterProfileType.BALANCED
                com.zbooster.app.ui.theme.ZPerformanceMode.AUTO -> BoosterProfileType.DEFAULT
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BoosterProfileType.DEFAULT)

    fun selectProfile(profile: BoosterProfileType) {
        viewModelScope.launch {
            val mappedPerfMode = when (profile) {
                BoosterProfileType.BATTERY_SAVER -> com.zbooster.app.ui.theme.ZPerformanceMode.LOW_END
                BoosterProfileType.PERFORMANCE, BoosterProfileType.EXTREME -> com.zbooster.app.ui.theme.ZPerformanceMode.HIGH_END
                BoosterProfileType.BALANCED -> com.zbooster.app.ui.theme.ZPerformanceMode.BALANCED
                BoosterProfileType.DEFAULT, BoosterProfileType.CUSTOM -> com.zbooster.app.ui.theme.ZPerformanceMode.AUTO
            }
            settingsRepository.setPerformanceMode(mappedPerfMode)
        }
    }
}
