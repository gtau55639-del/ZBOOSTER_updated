package com.zbooster.app.model

/**
 * Represents a detected/installed game and its ZBOOSTER-specific metadata.
 * `icon` is loaded lazily by the UI layer via PackageManager (not stored
 * here) to avoid holding Drawables in memory longer than needed.
 */
data class Game(
    val packageName: String,
    val appName: String,
    val isAddedToZBooster: Boolean = false,
    val isFavorite: Boolean = false,
    val category: GameCategory = GameCategory.ALL,
    val boosterProfile: BoosterProfileType = BoosterProfileType.DEFAULT,
    val lastPlayedTimestamp: Long? = null,
    val optimizationStatus: OptimizationStatus = OptimizationStatus.NOT_OPTIMIZED
)

enum class GameCategory { ALL, RECENTLY_PLAYED, FAVORITE, HIGH_PERFORMANCE, CUSTOM }

enum class OptimizationStatus { NOT_OPTIMIZED, OPTIMIZED, NOT_SUPPORTED }

enum class BoosterProfileType { DEFAULT, BALANCED, PERFORMANCE, EXTREME, BATTERY_SAVER, CUSTOM }
