package com.zbooster.app.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * ZBOOSTER color identity.
 * Kept deliberately narrow (per spec: don't overuse colors) —
 * two accent hues (red + cyber blue/purple) over a near-black base.
 */

// Base / surfaces
val ZBackground = Color(0xFF0A0A0F)      // primary app background
val ZSurface = Color(0xFF13131A)         // cards
val ZSurfaceElevated = Color(0xFF1B1B24) // elevated cards / sheets
val ZSurfaceBorder = Color(0xFF262631)   // hairline borders on cards
val ZDarkNavy = Color(0xFF0D1017)

// Accents
val ZElectricRed = Color(0xFFFF1E3C)
val ZNeonRed = Color(0xFFFF3B5C)
val ZCyberBlue = Color(0xFF2EE6FF)
val ZPurpleAccent = Color(0xFF8B5CF6)

// Status
val ZSuccess = Color(0xFF33D69F)
val ZWarning = Color(0xFFFFB020)
val ZDanger = ZElectricRed

// Text
val ZTextPrimary = Color(0xFFF5F5F7)
val ZTextSecondary = Color(0xFFA0A0AE)
val ZTextDisabled = Color(0xFF5C5C6B)
val ZSoftGray = Color(0xFF8A8A96)

// Gradients (used sparingly, e.g. Boost Now button / hero card glow)
val ZGradientStart = ZElectricRed
val ZGradientEnd = ZPurpleAccent
