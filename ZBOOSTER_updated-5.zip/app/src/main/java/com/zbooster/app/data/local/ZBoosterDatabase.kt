package com.zbooster.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [GameMetadataEntity::class],
    version = 1,
    exportSchema = false
)
abstract class ZBoosterDatabase : RoomDatabase() {

    abstract fun gameMetadataDao(): GameMetadataDao

    companion object {
        @Volatile
        private var INSTANCE: ZBoosterDatabase? = null

        fun getInstance(context: Context): ZBoosterDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ZBoosterDatabase::class.java,
                    "zbooster.db"
                )
                    // No real migrations exist yet (still schema version 1).
                    // This is a deliberate safety net: if a future release
                    // bumps the version without an explicit Migration, Room
                    // will recreate the DB instead of crashing existing
                    // users on update. The trade-off is that game metadata
                    // (per-game booster profile choices, recently-played)
                    // would be reset — acceptable for this non-critical
                    // cache-like data, but call out real Migration() objects
                    // here once the schema actually changes, and drop this
                    // fallback where user data matters more than uptime.
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
        }
    }
}
