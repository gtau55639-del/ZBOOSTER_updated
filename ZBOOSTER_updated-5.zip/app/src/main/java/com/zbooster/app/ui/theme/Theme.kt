package com.zbooster.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color

private val ZDarkColorScheme = darkColorScheme(
    primary = ZElectricRed,
    onPrimary = ZTextPrimary,
    secondary = ZCyberBlue,
    onSecondary = ZDarkNavy,
    tertiary = ZPurpleAccent,
    background = ZBackground,
    onBackground = ZTextPrimary,
    surface = ZSurface,
    onSurface = ZTextPrimary,
    surfaceVariant = ZSurfaceElevated,
    onSurfaceVariant = ZTextSecondary,
    outline = ZSurfaceBorder,
    error = ZDanger,
    onError = ZTextPrimary
)

// Optional light scheme (spec: "Light jika diperlukan") — same identity,
// lighter surfaces, still gaming-flavored rather than a generic Material light theme.
private val ZLightColorScheme = lightColorScheme(
    primary = ZElectricRed,
    onPrimary = Color(0xFFFFFFFF),
    secondary = ZCyberBlue,
    tertiary = ZPurpleAccent,
    background = Color(0xFFF4F4F7),
    onBackground = Color(0xFF16161C),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF16161C),
    surfaceVariant = Color(0xFFECECF2),
    outline = Color(0xFFD8D8E0),
    error = ZDanger
)

enum class ZThemeMode { DARK, AMOLED, LIGHT }

@Composable
fun ZBoosterTheme(
    themeMode: ZThemeMode = ZThemeMode.DARK,
    uiCapability: ZUiCapability = ZUiCapability(),
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        ZThemeMode.DARK -> ZDarkColorScheme
        ZThemeMode.AMOLED -> ZDarkColorScheme.copy(
            background = Color.Black,
            surface = Color(0xFF0A0A0A)
        )
        ZThemeMode.LIGHT -> ZLightColorScheme
    }

    CompositionLocalProvider(LocalZUiCapability provides uiCapability) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = ZBoosterTypography,
            shapes = ZBoosterShapes,
            content = content
        )
    }
}

/** Convenience: is the current system in dark mode (used for onboarding preview etc). */
@Composable
fun zIsSystemDark(): Boolean = isSystemInDarkTheme()
