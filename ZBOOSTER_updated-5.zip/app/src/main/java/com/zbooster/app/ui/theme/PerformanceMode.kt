package com.zbooster.app.ui.theme

import androidx.compose.runtime.compositionLocalOf

/**
 * Global UI performance mode (spec STEP 11/12).
 * AUTO decides LOW_END vs HIGH_END based on device capability
 * (RAM via ActivityManager.MemoryInfo + Build info) — see
 * util/DeviceCapability.kt. This value gates animation complexity,
 * blur usage, and lazy-loading aggressiveness across the whole app.
 */
enum class ZPerformanceMode { AUTO, LOW_END, BALANCED, HIGH_END }

/** Resolved effective mode (AUTO already turned into a concrete value upstream). */
data class ZUiCapability(
    val performanceMode: ZPerformanceMode = ZPerformanceMode.BALANCED,
    val reduceMotion: Boolean = false
) {
    /** Single source of truth: should heavy animations/glow/blur run? */
    val allowRichAnimation: Boolean
        get() = !reduceMotion && performanceMode != ZPerformanceMode.LOW_END

    /** Animation duration multiplier — shorter/none on constrained devices. */
    val animationDurationMs: Int
        get() = if (allowRichAnimation) 260 else 0
}

val LocalZUiCapability = compositionLocalOf { ZUiCapability() }
