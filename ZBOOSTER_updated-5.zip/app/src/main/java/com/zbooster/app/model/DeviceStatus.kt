package com.zbooster.app.model

/**
 * Honest snapshot of device status. Any field Android cannot legitimately
 * report is left null and the UI shows "Not available" rather than a
 * fabricated number (spec #8 / #18 — no fake data, ever).
 */
data class DeviceStatus(
    val cpuUsagePercent: Int?,      // best-effort, may be null on some OEMs/API levels
    val ramUsagePercent: Int,       // always available via ActivityManager
    val batteryPercent: Int,        // always available via BatteryManager
    val temperatureCelsius: Float?, // null if system does not expose it
    val isCharging: Boolean
) {
    val isGamingReady: Boolean
        get() = ramUsagePercent < 90 && batteryPercent > 15
}
