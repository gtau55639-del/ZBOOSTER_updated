package com.zbooster.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface GameMetadataDao {

    @Query("SELECT * FROM game_metadata")
    fun observeAll(): Flow<List<GameMetadataEntity>>

    @Query("SELECT * FROM game_metadata WHERE packageName = :packageName LIMIT 1")
    suspend fun getByPackage(packageName: String): GameMetadataEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: GameMetadataEntity)

    @Update
    suspend fun update(entity: GameMetadataEntity)

    @Query("DELETE FROM game_metadata WHERE packageName = :packageName")
    suspend fun delete(packageName: String)

    @Query("UPDATE game_metadata SET isFavorite = :isFavorite WHERE packageName = :packageName")
    suspend fun setFavorite(packageName: String, isFavorite: Boolean)

    @Query("UPDATE game_metadata SET lastPlayedTimestamp = :timestamp WHERE packageName = :packageName")
    suspend fun setLastPlayed(packageName: String, timestamp: Long)

    @Query("UPDATE game_metadata SET boosterProfile = :profile WHERE packageName = :packageName")
    suspend fun setBoosterProfile(packageName: String, profile: String)
}
