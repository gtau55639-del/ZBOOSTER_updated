package com.zbooster.app.util

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import com.zbooster.app.model.PerformanceSample

/**
 * Reads real, currently-available system metrics for the Performance
 * Monitor. Does not read per-app CPU usage or GPU temperature — Android
 * does not expose reliable, universal public APIs for these without root,
 * so those fields are reported as null/unavailable rather than guessed
 * (spec #8/#18).
 */
object PerformanceSampler {

    fun sample(context: Context): PerformanceSample {
        val ramUsage = DeviceCapability.ramUsagePercent(context)
        val battery = readBattery(context)
        val network = readNetworkType(context)

        return PerformanceSample(
            timestampMs = System.currentTimeMillis(),
            ramUsagePercent = ramUsage,
            batteryPercent = battery.percent,
            cpuUsagePercent = null,
            temperatureCelsius = battery.temperatureCelsius,
            networkType = network,
            fpsAvailable = false, // no universal legal FPS read for arbitrary games
            fps = null
        )
    }

    private data class BatteryReading(val percent: Int, val temperatureCelsius: Float?)

    private fun readBattery(context: Context): BatteryReading {
        return try {
            val intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus = context.registerReceiver(null, intentFilter)
            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val percent = if (level >= 0 && scale > 0) (level * 100 / scale) else 0
            // EXTRA_TEMPERATURE is in tenths of a degree Celsius, and IS a
            // real, documented system broadcast extra (not fabricated).
            val tempTenths = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            val temperature = if (tempTenths != null && tempTenths != Int.MIN_VALUE) tempTenths / 10f else null
            BatteryReading(percent, temperature)
        } catch (e: Exception) {
            BatteryReading(0, null)
        }
    }

    private fun readNetworkType(context: Context): String {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return "Unknown"
            val network = cm.activeNetwork ?: return "Offline"
            val capabilities = cm.getNetworkCapabilities(network) ?: return "Offline"
            when {
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile Data"
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                else -> "Connected"
            }
        } catch (e: Exception) {
            "Unknown"
        }
    }
}
