package com.zbooster.app.ui.screens.boost

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zbooster.app.model.BoosterProfileInfo
import com.zbooster.app.model.boosterProfileCatalog
import com.zbooster.app.ui.components.ZCard
import com.zbooster.app.ui.theme.ZSuccess
import com.zbooster.app.ui.theme.ZTextSecondary

@Composable
fun BoostScreen(viewModel: BoostViewModel = viewModel()) {
    val activeProfile by viewModel.activeProfile.collectAsStateWithLifecycle()
    var infoProfile by androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf<BoosterProfileInfo?>(null)
    }

    Column(Modifier.fillMaxSize()) {
        Text(
            text = "Boost Profiles",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(16.dp)
        )
        Text(
            text = "Choose how ZBOOSTER balances performance and battery across the whole app.",
            style = MaterialTheme.typography.bodyMedium,
            color = ZTextSecondary,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(boosterProfileCatalog, key = { it.type }) { info ->
                ProfileRow(
                    info = info,
                    isActive = activeProfile == info.type,
                    onClick = { viewModel.selectProfile(info.type) },
                    onChipClick = { infoProfile = info }
                )
            }
        }
    }

    infoProfile?.let { info ->
        AlertDialog(
            onDismissRequest = { infoProfile = null },
            title = { Text(info.title) },
            text = { Text("${info.emphasis}: ${info.description}") },
            confirmButton = {
                TextButton(onClick = { infoProfile = null }) { Text("Got it") }
            }
        )
    }
}

@Composable
private fun ProfileRow(
    info: BoosterProfileInfo,
    isActive: Boolean,
    onClick: () -> Unit,
    onChipClick: () -> Unit
) {
    ZCard(modifier = Modifier.clickable(onClick = onClick)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(info.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    AssistChip(onClick = onChipClick, label = { Text(info.emphasis, style = MaterialTheme.typography.labelSmall) })
                }
                Spacer(Modifier.height(4.dp))
                Text(info.description, style = MaterialTheme.typography.bodyMedium, color = ZTextSecondary)
            }
            Spacer(Modifier.width(12.dp))
            Icon(
                imageVector = if (isActive) Icons.Filled.CheckCircle else Icons.Outlined.Circle,
                contentDescription = if (isActive) "Active" else "Inactive",
                tint = if (isActive) ZSuccess else ZTextSecondary
            )
        }
    }
}
