package com.zbooster.app.ui.screens.gamedetail

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zbooster.app.model.BoosterProfileType
import com.zbooster.app.model.Game
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class GameDetailViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as com.zbooster.app.ZBoosterApplication).gameRepository

    private val _game = MutableStateFlow<Game?>(null)
    val game: StateFlow<Game?> = _game.asStateFlow()

    private val _isLaunching = MutableStateFlow(false)
    val isLaunching: StateFlow<Boolean> = _isLaunching.asStateFlow()

    fun load(packageName: String) {
        viewModelScope.launch {
            repository.observeGames().collect { games ->
                _game.value = games.find { it.packageName == packageName }
            }
        }
    }

    fun setProfile(packageName: String, profile: BoosterProfileType) {
        viewModelScope.launch { repository.setBoosterProfile(packageName, profile) }
    }

    /**
     * Runs the selected booster profile's legitimate app-level adjustments,
     * marks the game as launched (for Recently Played), then returns a
     * launch Intent for the UI to start — the actual `startActivity` call
     * must happen from a Context, so the screen performs that step.
     */
    fun prepareLaunch(packageName: String, onReady: (Intent?) -> Unit) {
        viewModelScope.launch {
            _isLaunching.value = true
            repository.markLaunched(packageName)
            // Legal, app-level "profile activation" placeholder — e.g. this
            // is where DND/keep-screen-on toggles (already implemented in
            // Settings/DataStore) would be read and applied before launch.
            kotlinx.coroutines.delay(400)
            val intent = getApplication<Application>()
                .packageManager
                .getLaunchIntentForPackage(packageName)
            _isLaunching.value = false
            onReady(intent)
        }
    }
}
