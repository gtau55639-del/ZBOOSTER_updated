package com.zbooster.app.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.zbooster.app.R
import com.zbooster.app.ZBoosterApplication
import com.zbooster.app.manager.BoosterManager
import com.zbooster.app.util.DeviceCapability
import com.zbooster.app.util.PermissionHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * The floating Game Overlay panel (spec: "Panel Game Overlay (floating)").
 *
 * A genuine [WindowManager]-drawn overlay, not a placeholder: it starts as
 * a small draggable bubble, expands into a panel with live RAM/Battery
 * numbers (reusing the same honest [DeviceCapability] readers as the rest
 * of the app — no fabricated stats) and a real "Boost Now" button wired to
 * [BoosterManager].
 *
 * Uses plain Android views (not Compose) — a WindowManager-attached window
 * has no Activity/Lifecycle/ViewModelStore to host a ComposeView safely,
 * and pulling that machinery into a bare Service would add a lot of
 * fragile plumbing for a small floating panel.
 *
 * Never assumes SYSTEM_ALERT_WINDOW is granted: [onCreate] re-checks via
 * [PermissionHelper] and stops itself immediately (no crash, no silent
 * infinite retry) if it isn't.
 */
class GameOverlayService : Service() {

    companion object {
        private const val STATS_REFRESH_INTERVAL_MS = 2000L
    }

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var boosterManager: BoosterManager? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private var serviceScope: CoroutineScope? = null
    private var isBoosting = false

    private val statsRefreshRunnable = object : Runnable {
        override fun run() {
            refreshStats()
            mainHandler.postDelayed(this, STATS_REFRESH_INTERVAL_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()

        if (!PermissionHelper.hasOverlayPermission(this)) {
            // Never silently spin forever without the permission it needs.
            stopSelf()
            return
        }

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        boosterManager = BoosterManager(applicationContext)
        val job = Job()
        serviceScope = CoroutineScope(Dispatchers.Main + job)

        showBubble()
        mainHandler.post(statsRefreshRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        mainHandler.removeCallbacks(statsRefreshRunnable)
        removeBubble()
        removePanel()
        serviceScope?.cancel()
        serviceScope = null
    }

    // ---- Bubble (collapsed) ----------------------------------------------

    private fun overlayWindowType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun baseOverlayFlags(): Int =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private fun showBubble() {
        if (bubbleView != null) return
        val view = LayoutInflater.from(this).inflate(R.layout.view_overlay_bubble, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            baseOverlayFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 300
        }

        makeDraggable(view, params, onTap = {
            removeBubble()
            showPanel()
        })

        runCatching { windowManager.addView(view, params) }
            .onFailure { stopSelf() } // e.g. permission revoked mid-session
            .onSuccess { bubbleView = view }
    }

    private fun removeBubble() {
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        bubbleView = null
    }

    // ---- Panel (expanded) -------------------------------------------------

    private fun showPanel() {
        if (panelView != null) return
        val view = LayoutInflater.from(this).inflate(R.layout.view_overlay_panel, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            baseOverlayFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 300
        }

        val dragHandle = view.findViewById<View>(R.id.overlay_drag_handle)
        makeDraggable(dragHandle, params, onTap = null, rootView = view)

        view.findViewById<View>(R.id.overlay_minimize_button).setOnClickListener {
            removePanel()
            showBubble()
        }
        view.findViewById<View>(R.id.overlay_close_button).setOnClickListener {
            stopOverlayCompletely()
        }
        view.findViewById<View>(R.id.overlay_boost_button).setOnClickListener {
            runBoostFromOverlay(view)
        }

        runCatching { windowManager.addView(view, params) }
            .onFailure { stopSelf() }
            .onSuccess { panelView = view }

        refreshStats()
    }

    private fun removePanel() {
        panelView?.let { runCatching { windowManager.removeView(it) } }
        panelView = null
    }

    /** User tapped the panel's close (X) button: tear the overlay down and turn the Settings toggle off too. */
    private fun stopOverlayCompletely() {
        val app = application as? ZBoosterApplication
        serviceScope?.launch {
            app?.settingsRepository?.setOverlayEnabled(false)
        }
        stopSelf()
    }

    private fun runBoostFromOverlay(panel: View) {
        if (isBoosting) return
        val button = panel.findViewById<TextView>(R.id.overlay_boost_button)
        isBoosting = true
        button.text = "BOOSTING…"
        serviceScope?.launch {
            boosterManager?.runBoost()
            isBoosting = false
            button.text = "BOOST NOW"
            refreshStats()
        }
    }

    // ---- Live stats ---------------------------------------------------------

    private fun refreshStats() {
        val panel = panelView ?: return
        val ramValue = panel.findViewById<TextView>(R.id.overlay_ram_value)
        val batteryValue = panel.findViewById<TextView>(R.id.overlay_battery_value)

        val ramPercent = DeviceCapability.ramUsagePercent(this)
        ramValue.text = "$ramPercent%"

        val batteryManager = getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val batteryPercent = batteryManager
            ?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            ?.takeIf { it in 0..100 }
        batteryValue.text = batteryPercent?.let { "$it%" } ?: "N/A"
    }

    // ---- Drag handling --------------------------------------------------------

    /**
     * Attaches a drag-to-move + tap-to-trigger touch listener to [touchTarget].
     * [rootView] (defaults to [touchTarget]) is the actual window view moved
     * via [WindowManager.updateViewLayout] — useful when the draggable
     * handle is a child of the real overlay window (the expanded panel's
     * title bar), not the window's own root.
     */
    private fun makeDraggable(
        touchTarget: View,
        params: WindowManager.LayoutParams,
        onTap: (() -> Unit)?,
        rootView: View = touchTarget
    ) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var totalMovement = 0f
        val tapSlopPx = 12f

        touchTarget.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    totalMovement = 0f
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX)
                    val dy = (event.rawY - initialTouchY)
                    totalMovement += abs(dx) + abs(dy)
                    params.x = initialX + dx.toInt()
                    params.y = initialY + dy.toInt()
                    if (rootView.isAttachedToWindow) {
                        runCatching { windowManager.updateViewLayout(rootView, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (onTap != null && totalMovement < tapSlopPx) onTap()
                    true
                }
                else -> false
            }
        }
    }
}
