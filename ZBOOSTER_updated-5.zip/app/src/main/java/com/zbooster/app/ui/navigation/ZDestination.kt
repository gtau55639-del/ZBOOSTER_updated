package com.zbooster.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.ui.graphics.vector.ImageVector
import com.zbooster.app.R

sealed class ZDestination(val route: String, val labelRes: Int, val icon: ImageVector) {
    data object Home : ZDestination("home", R.string.nav_home, Icons.Filled.Home)
    data object Games : ZDestination("games", R.string.nav_games, Icons.Filled.SportsEsports)
    data object Boost : ZDestination("boost", R.string.nav_boost, Icons.Filled.Bolt)
    data object Monitor : ZDestination("monitor", R.string.nav_monitor, Icons.Filled.Insights)
    data object Settings : ZDestination("settings", R.string.nav_settings, Icons.Filled.Settings)

    companion object {
        val bottomNavItems = listOf(Home, Games, Boost, Monitor, Settings)
    }
}

// Non-bottom-nav routes
const val ROUTE_ONBOARDING = "onboarding"
const val ROUTE_GAME_DETAIL = "game_detail/{gameId}"
fun gameDetailRoute(gameId: String) = "game_detail/$gameId"
const val ROUTE_ABOUT = "about"
