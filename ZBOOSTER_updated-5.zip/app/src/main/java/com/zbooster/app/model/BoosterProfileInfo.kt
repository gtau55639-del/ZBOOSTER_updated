package com.zbooster.app.model

/**
 * Static, honest description of what each profile actually configures at
 * the app level (spec STEP 6). No profile claims to overclock hardware or
 * add RAM — see BoosterManager / spec #18.
 */
data class BoosterProfileInfo(
    val type: BoosterProfileType,
    val title: String,
    val description: String,
    val emphasis: String // short chip text, e.g. "Balanced", "Max Performance"
)

val boosterProfileCatalog: List<BoosterProfileInfo> = listOf(
    BoosterProfileInfo(
        type = BoosterProfileType.DEFAULT,
        title = "Default",
        description = "No special adjustments. Standard system behavior.",
        emphasis = "Standard"
    ),
    BoosterProfileInfo(
        type = BoosterProfileType.BALANCED,
        title = "Balanced",
        description = "Balances performance and battery life for everyday gaming sessions.",
        emphasis = "Balanced"
    ),
    BoosterProfileInfo(
        type = BoosterProfileType.PERFORMANCE,
        title = "Performance",
        description = "Prioritizes smoother gameplay: reduces ZBOOSTER's own background activity and keeps the screen on.",
        emphasis = "Prioritize Performance"
    ),
    BoosterProfileInfo(
        type = BoosterProfileType.EXTREME,
        title = "Extreme",
        description = "Applies every app-level optimization ZBOOSTER can legally perform without root. Does not overclock the CPU/GPU.",
        emphasis = "Maximum (No Root)"
    ),
    BoosterProfileInfo(
        type = BoosterProfileType.BATTERY_SAVER,
        title = "Battery Saver",
        description = "Reduces ZBOOSTER's own background work and monitoring frequency to save battery.",
        emphasis = "Efficiency First"
    ),
    BoosterProfileInfo(
        type = BoosterProfileType.CUSTOM,
        title = "Custom",
        description = "Choose your own combination of settings from the Boost Settings screen.",
        emphasis = "User Defined"
    )
)
