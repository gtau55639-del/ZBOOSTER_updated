package com.zbooster.app.model

/**
 * A single point-in-time performance reading. Every field is either backed
 * by a real Android API or explicitly null (spec #8/#18: never fabricate
 * numbers, show "not available" instead).
 */
data class PerformanceSample(
    val timestampMs: Long,
    val ramUsagePercent: Int,          // real: ActivityManager.MemoryInfo
    val batteryPercent: Int,           // real: BatteryManager
    val cpuUsagePercent: Int?,         // null: no public universal API without root
    val temperatureCelsius: Float?,    // real if BatteryManager exposes it; else null
    val networkType: String,           // real: ConnectivityManager (Wi-Fi / Mobile / Offline)
    val fpsAvailable: Boolean = false, // true only if a legitimate FPS source exists
    val fps: Int? = null
)

enum class MonitorGraphMode { LIVE, SIMPLE, DETAILED }
