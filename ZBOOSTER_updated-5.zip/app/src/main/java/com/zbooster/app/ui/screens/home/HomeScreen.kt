package com.zbooster.app.ui.screens.home

import android.content.Intent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zbooster.app.R
import com.zbooster.app.model.DeviceStatus
import com.zbooster.app.ui.components.ZCard
import com.zbooster.app.ui.theme.*

@Composable
fun HomeScreen(
    windowSize: ZWindowSize,
    onOpenSettings: () -> Unit,
    onGoToBoostProfiles: () -> Unit,
    viewModel: HomeViewModel = viewModel()
) {
    val deviceStatus by viewModel.deviceStatus.collectAsStateWithLifecycle()
    val boostState by viewModel.boostState.collectAsStateWithLifecycle()
    val uiCapability = LocalZUiCapability.current
    val padding = windowSize.contentPadding().dp

    LaunchedEffect(Unit) { viewModel.refreshStatus() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(horizontal = padding, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { HomeTopBar(onOpenSettings = onOpenSettings) }

        item {
            HeroPerformanceCard(
                status = deviceStatus,
                boostState = boostState,
                allowRichAnimation = uiCapability.allowRichAnimation,
                onBoostNow = viewModel::onBoostNow,
                onDismissComplete = viewModel::acknowledgeBoostComplete
            )
        }

        item { QuickStatsRow(status = deviceStatus) }

        item {
            QuickActionCard(
                title = "Boost Profiles",
                subtitle = "Balanced, Performance, Extreme & more",
                onClick = onGoToBoostProfiles
            )
        }
    }
}

@Composable
private fun HomeTopBar(onOpenSettings: () -> Unit) {
    val context = LocalContext.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.foundation.Image(
                    painter = painterResource(id = R.drawable.ic_zbooster_logo),
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(Modifier.width(10.dp))
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }
        Row {
            IconButton(onClick = {
                // Opens ZBOOSTER's own notification settings page in system
                // Settings, so the bell icon does something real: it takes
                // the user straight to where they can manage ZBOOSTER's
                // notification channels (e.g. the monitor notification).
                val intent = Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.packageName)
                }
                runCatching { context.startActivity(intent) }
            }) {
                Icon(Icons.Filled.Notifications, contentDescription = "Notifications")
            }
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Settings")
            }
        }
    }
}

@Composable
private fun HeroPerformanceCard(
    status: DeviceStatus,
    boostState: BoostUiState,
    allowRichAnimation: Boolean,
    onBoostNow: () -> Unit,
    onDismissComplete: () -> Unit
) {
    ZCard {
        Column(Modifier.padding(20.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = stringResource(R.string.home_device_status),
                        style = MaterialTheme.typography.labelMedium,
                        color = ZTextSecondary
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = if (status.isGamingReady) stringResource(R.string.home_gaming_ready) else "Needs Attention",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = if (status.isGamingReady) ZSuccess else ZWarning
                    )
                }
                StatusDot(isReady = status.isGamingReady)
            }

            Spacer(Modifier.height(20.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                MetricGauge(
                    label = "CPU",
                    valueText = status.cpuUsagePercent?.let { "$it%" } ?: "N/A",
                    percent = status.cpuUsagePercent,
                    icon = Icons.Filled.Speed,
                    color = ZCyberBlue
                )
                MetricGauge(
                    label = "RAM",
                    valueText = "${status.ramUsagePercent}%",
                    percent = status.ramUsagePercent,
                    icon = Icons.Filled.Memory,
                    color = ZPurpleAccent
                )
                MetricGauge(
                    label = "Battery",
                    valueText = "${status.batteryPercent}%",
                    percent = status.batteryPercent,
                    icon = Icons.Filled.BatteryChargingFull,
                    color = ZElectricRed
                )
            }

            Spacer(Modifier.height(20.dp))

            BoostNowButton(
                state = boostState,
                allowRichAnimation = allowRichAnimation,
                onClick = onBoostNow,
                onDismissComplete = onDismissComplete
            )
        }
    }
}

@Composable
private fun StatusDot(isReady: Boolean) {
    Box(
        modifier = Modifier
            .size(12.dp)
            .clip(CircleShape)
            .background(if (isReady) ZSuccess else ZWarning)
    )
}

@Composable
private fun MetricGauge(
    label: String,
    valueText: String,
    percent: Int?,
    icon: ImageVector,
    color: androidx.compose.ui.graphics.Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = { (percent ?: 0) / 100f },
                modifier = Modifier.size(56.dp),
                color = color,
                trackColor = ZSurfaceBorder,
                strokeWidth = 4.dp
            )
            Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(valueText, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
        Text(label, style = MaterialTheme.typography.labelSmall, color = ZTextSecondary)
    }
}

@Composable
private fun BoostNowButton(
    state: BoostUiState,
    allowRichAnimation: Boolean,
    onClick: () -> Unit,
    onDismissComplete: () -> Unit
) {
    val scale by animateFloatAsState(
        targetValue = if (state == BoostUiState.BOOSTING && allowRichAnimation) 0.97f else 1f,
        animationSpec = tween(if (allowRichAnimation) 220 else 0),
        label = "boostButtonScale"
    )

    LaunchedEffect(state) {
        if (state == BoostUiState.COMPLETE) {
            kotlinx.coroutines.delay(2200)
            onDismissComplete()
        }
    }

    Button(
        onClick = onClick,
        enabled = state != BoostUiState.BOOSTING,
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .scale(scale),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = ZElectricRed,
            contentColor = androidx.compose.ui.graphics.Color.White,
            disabledContainerColor = ZElectricRed.copy(alpha = 0.6f)
        )
    ) {
        when (state) {
            BoostUiState.IDLE -> Text(
                stringResource(R.string.home_boost_now),
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelLarge
            )
            BoostUiState.BOOSTING -> Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = androidx.compose.ui.graphics.Color.White
                )
                Spacer(Modifier.width(10.dp))
                Text("Optimizing…", fontWeight = FontWeight.Bold)
            }
            BoostUiState.COMPLETE -> Text(
                stringResource(R.string.home_boost_complete),
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun QuickStatsRow(status: DeviceStatus) {
    ZCard {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = if (status.temperatureCelsius != null) "${status.temperatureCelsius}°C" else stringResource(R.string.not_supported_on_device),
                style = MaterialTheme.typography.bodyMedium,
                color = ZTextSecondary
            )
            Text(
                text = if (status.isCharging) "Charging" else "On Battery",
                style = MaterialTheme.typography.bodyMedium,
                color = ZTextSecondary
            )
        }
    }
}

@Composable
private fun QuickActionCard(title: String, subtitle: String, onClick: () -> Unit) {
    ZCard(modifier = Modifier.clip(RoundedCornerShape(20.dp))) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .then(Modifier),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = ZTextSecondary)
            }
            TextButton(onClick = onClick) { Text("Open") }
        }
    }
}
