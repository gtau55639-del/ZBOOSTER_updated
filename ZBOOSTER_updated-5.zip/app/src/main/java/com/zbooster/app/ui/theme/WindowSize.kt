package com.zbooster.app.ui.theme

/**
 * ZBOOSTER responsive breakpoints, matching STEP 10 of the spec:
 *  - Compact : 320dp–400dp  (small phones)
 *  - Medium  : 400dp–600dp  (normal phones)
 *  - Expanded: 600dp+       (tablets / foldables / landscape)
 *
 * Used together with androidx.compose.material3.windowsizeclass so real
 * width in dp drives layout decisions instead of fixed/hardcoded sizes.
 */
enum class ZWindowSize { COMPACT, MEDIUM, EXPANDED }

fun widthDpToZWindowSize(widthDp: Int): ZWindowSize = when {
    widthDp < 400 -> ZWindowSize.COMPACT
    widthDp < 600 -> ZWindowSize.MEDIUM
    else -> ZWindowSize.EXPANDED
}

/** Grid column count for Game Library depending on breakpoint. */
fun ZWindowSize.gameGridColumns(): Int = when (this) {
    ZWindowSize.COMPACT -> 2
    ZWindowSize.MEDIUM -> 3
    ZWindowSize.EXPANDED -> 5
}

/** Horizontal content padding depending on breakpoint. */
fun ZWindowSize.contentPadding(): Int = when (this) {
    ZWindowSize.COMPACT -> 12
    ZWindowSize.MEDIUM -> 20
    ZWindowSize.EXPANDED -> 32
}
