package com.zbooster.app.data.repository

import android.content.Context
import com.zbooster.app.data.local.GameMetadataDao
import com.zbooster.app.data.local.GameMetadataEntity
import com.zbooster.app.data.local.ZBoosterDatabase
import com.zbooster.app.model.BoosterProfileType
import com.zbooster.app.model.Game
import com.zbooster.app.model.GameCategory
import com.zbooster.app.model.OptimizationStatus
import com.zbooster.app.util.InstalledAppsReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class GameRepository(private val context: Context) {

    private val dao: GameMetadataDao = ZBoosterDatabase.getInstance(context).gameMetadataDao()

    /**
     * Live-scans installed games via PackageManager, then merges each with
     * whatever ZBOOSTER metadata (favorite/category/profile) is stored in
     * Room. The scan itself is not cached in Room — it is always a fresh,
     * honest read of what's actually installed right now.
     *
     * [refreshTrigger] re-runs the PackageManager scan every time it emits
     * a new value (e.g. from a "Refresh Game List" button), in addition to
     * the initial scan on first collection.
     */
    fun observeGames(refreshTrigger: Flow<Int> = flow { emit(0) }): Flow<List<Game>> {
        val installedFlow = refreshTrigger
            .map { InstalledAppsReader.getInstalledGames(context) }
            .flowOn(Dispatchers.Default) // PackageManager scan off the main thread
        return combine(installedFlow, dao.observeAll()) { installed, metadataList ->
            mergeGamesWithMetadata(installed, metadataList)
        }
    }

    companion object {
        /**
         * Pure merge of a fresh PackageManager scan with whatever ZBOOSTER
         * metadata is stored in Room. Deliberately takes plain data classes
         * only (no [Context], no DAO, no Flow) so it is fully unit-testable
         * on the JVM without an emulator/instrumentation.
         */
        fun mergeGamesWithMetadata(
            installed: List<InstalledAppsReader.InstalledApp>,
            metadataList: List<GameMetadataEntity>
        ): List<Game> {
            val metadataByPackage = metadataList.associateBy { it.packageName }
            return installed.map { app ->
                val meta = metadataByPackage[app.packageName]
                Game(
                    packageName = app.packageName,
                    appName = app.appName,
                    isAddedToZBooster = meta?.isAddedToZBooster ?: false,
                    isFavorite = meta?.isFavorite ?: false,
                    category = meta?.category?.let { runCatching { GameCategory.valueOf(it) }.getOrNull() } ?: GameCategory.ALL,
                    boosterProfile = meta?.boosterProfile?.let { runCatching { BoosterProfileType.valueOf(it) }.getOrNull() } ?: BoosterProfileType.DEFAULT,
                    lastPlayedTimestamp = meta?.lastPlayedTimestamp,
                    optimizationStatus = if (meta?.isAddedToZBooster == true) OptimizationStatus.OPTIMIZED else OptimizationStatus.NOT_OPTIMIZED
                )
            }
        }
    }

    suspend fun refreshInstalledGamesOnce(): List<Game> = withContext(Dispatchers.IO) {
        InstalledAppsReader.getInstalledGames(context).map { app ->
            Game(packageName = app.packageName, appName = app.appName)
        }
    }

    suspend fun addToZBooster(packageName: String) = withContext(Dispatchers.IO) {
        val existing = dao.getByPackage(packageName)
        dao.upsert(
            (existing ?: GameMetadataEntity(packageName = packageName)).copy(isAddedToZBooster = true)
        )
    }

    suspend fun removeFromZBooster(packageName: String) = withContext(Dispatchers.IO) {
        val existing = dao.getByPackage(packageName) ?: return@withContext
        dao.upsert(existing.copy(isAddedToZBooster = false))
    }

    suspend fun toggleFavorite(packageName: String, isFavorite: Boolean) = withContext(Dispatchers.IO) {
        val existing = dao.getByPackage(packageName)
        if (existing == null) {
            dao.upsert(GameMetadataEntity(packageName = packageName, isFavorite = isFavorite))
        } else {
            dao.setFavorite(packageName, isFavorite)
        }
    }

    suspend fun setBoosterProfile(packageName: String, profile: BoosterProfileType) = withContext(Dispatchers.IO) {
        val existing = dao.getByPackage(packageName)
        if (existing == null) {
            dao.upsert(GameMetadataEntity(packageName = packageName, boosterProfile = profile.name))
        } else {
            dao.setBoosterProfile(packageName, profile.name)
        }
    }

    suspend fun markLaunched(packageName: String) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val existing = dao.getByPackage(packageName)
        if (existing == null) {
            dao.upsert(GameMetadataEntity(packageName = packageName, lastPlayedTimestamp = now))
        } else {
            dao.setLastPlayed(packageName, now)
        }
    }
}
