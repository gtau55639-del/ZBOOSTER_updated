package com.zbooster.app.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.zbooster.app.ZBoosterApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Real implementation behind the "Block Notifications" toggle in Settings.
 *
 * This is a genuine NotificationListenerService: once the user grants
 * Notification Access (via [com.zbooster.app.util.PermissionHelper]'s
 * settings intent — ZBOOSTER never assumes this is granted), it silently
 * cancels incoming notification banners from OTHER apps while the toggle
 * is on. ZBOOSTER's own notifications (e.g. the monitor foreground
 * notification) are always left alone.
 *
 * Honesty note: this blocks notifications for as long as the toggle is
 * on — it is not scoped to "only while a specific game is in the
 * foreground", because reliably detecting foreground-app changes would
 * require the separate PACKAGE_USAGE_STATS permission, which ZBOOSTER
 * does not request. The Settings subtitle should be read as "while this
 * switch is on", not as an automatic per-game session.
 */
class ZNotificationBlockerService : NotificationListenerService() {

    private var scope: CoroutineScope? = null

    @Volatile
    private var blockingEnabled: Boolean = false

    override fun onListenerConnected() {
        super.onListenerConnected()
        val job = Job()
        val newScope = CoroutineScope(Dispatchers.Default + job)
        scope = newScope

        val app = application as? ZBoosterApplication
        if (app != null) {
            newScope.launch {
                app.settingsRepository.blockNotifications.collect { enabled ->
                    blockingEnabled = enabled
                }
            }
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        scope?.cancel()
        scope = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return
        if (!blockingEnabled) return
        // Never touch our own notifications (e.g. the monitor's persistent
        // "live monitoring active" notification).
        if (sbn.packageName == packageName) return

        try {
            cancelNotification(sbn.key)
        } catch (_: SecurityException) {
            // Access can be revoked by the user at any time; fail silently.
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope?.cancel()
        scope = null
    }
}
