package com.zbooster.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.zbooster.app.MainActivity
import com.zbooster.app.R

/**
 * Minimal, honest foreground service: its only job is to keep Android from
 * killing the live Performance Monitor / Game Overlay while the user has
 * explicitly turned one of them on, and to show the required persistent
 * notification while doing so (per Android's foreground service rules).
 *
 * It performs NO background work when not explicitly started, and is
 * stopped immediately via [ACTION_STOP] when the user turns monitoring
 * off — consistent with spec #11 ("jangan menjalankan service terus-menerus
 * tanpa alasan").
 */
class BoosterMonitorService : Service() {

    companion object {
        const val ACTION_START = "com.zbooster.app.action.START_MONITOR"
        const val ACTION_STOP = "com.zbooster.app.action.STOP_MONITOR"
        private const val CHANNEL_ID = "zbooster_monitor_channel"
        private const val NOTIFICATION_ID = 1001
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            else -> {
                createNotificationChannelIfNeeded()
                startForeground(NOTIFICATION_ID, buildNotification())
            }
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText("Live performance monitoring is active")
            .setSmallIcon(R.drawable.ic_zbooster_logo)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val existing = manager?.getNotificationChannel(CHANNEL_ID)
            if (existing == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "ZBOOSTER Monitoring",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Shown while live performance monitoring or the game overlay is active"
                }
                manager?.createNotificationChannel(channel)
            }
        }
    }
}
