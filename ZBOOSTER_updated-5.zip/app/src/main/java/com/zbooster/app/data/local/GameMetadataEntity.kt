package com.zbooster.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Persisted, user-controlled metadata for a game. We do NOT store a copy
 * of every installed app here — only games the user has added to
 * ZBOOSTER, marked favorite, or customized a profile for. The live list
 * of "is this installed" always comes fresh from PackageManager.
 */
@Entity(tableName = "game_metadata")
data class GameMetadataEntity(
    @PrimaryKey val packageName: String,
    val isAddedToZBooster: Boolean = false,
    val isFavorite: Boolean = false,
    val category: String = "ALL",
    val boosterProfile: String = "DEFAULT",
    val lastPlayedTimestamp: Long? = null
)
