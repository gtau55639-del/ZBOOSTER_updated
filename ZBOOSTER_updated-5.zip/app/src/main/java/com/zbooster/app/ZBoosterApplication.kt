package com.zbooster.app

import android.app.Application
import com.zbooster.app.data.repository.GameRepository
import com.zbooster.app.data.repository.SettingsRepository

class ZBoosterApplication : Application() {

    // Simple manual DI: one shared repository instance for the whole app.
    // (Kept intentionally lightweight — no Hilt/Dagger — to keep the app
    // small and fast on low-end devices, per spec section 11.)
    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var gameRepository: GameRepository
        private set

    override fun onCreate() {
        super.onCreate()
        settingsRepository = SettingsRepository(applicationContext)
        gameRepository = GameRepository(applicationContext)
    }
}
