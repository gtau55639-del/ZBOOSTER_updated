package com.zbooster.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.zbooster.app.ui.theme.ZSurfaceBorder

/**
 * Base card used across Home/Games/Monitor — a flat, low-cost surface
 * with a hairline border instead of expensive shadows/blur, so it stays
 * cheap to render on low-end devices (spec #11).
 */
@Composable
fun ZCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, ZSurfaceBorder)
    ) {
        Box(Modifier.fillMaxWidth()) { content() }
    }
}

/** Gradient variant reserved for hero/CTA elements only (used sparingly). */
@Composable
fun ZGradientSurface(
    modifier: Modifier = Modifier,
    colors: List<androidx.compose.ui.graphics.Color>,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(colors))
    ) {
        content()
    }
}
