package com.zbooster.app.data.repository

import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import com.zbooster.app.ui.theme.ZPerformanceMode
import com.zbooster.app.ui.theme.ZThemeMode
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue

/**
 * Instrumented test for [SettingsRepository], backed by a real Jetpack
 * DataStore on the device/emulator's filesystem (spec STEP 9). This is NOT
 * a JVM unit test — it needs `./gradlew connectedAndroidTest` against a
 * running emulator or physical device, since DataStore-preferences reads
 * and writes actual files under the app's data directory.
 *
 * Every test resets all settings first/last so the suite is order-independent
 * and doesn't leak state into other instrumented tests that touch the same
 * DataStore file ("zbooster_settings").
 */
@RunWith(AndroidJUnit4::class)
@LargeTest
class SettingsRepositoryInstrumentedTest {

    private val context = ApplicationProvider.getApplicationContext<android.content.Context>()
    private val repository = SettingsRepository(context)

    @Before
    fun resetSettings() = runBlocking {
        repository.resetAll()
    }

    @After
    fun cleanUp() = runBlocking {
        repository.resetAll()
    }

    @Test
    fun defaultsAreAppliedOnFreshDataStore() = runBlocking {
        assertEquals(ZThemeMode.DARK, repository.themeMode.first())
        assertEquals(ZPerformanceMode.AUTO, repository.performanceMode.first())
        assertFalse(repository.reduceAnimation.first())
        assertFalse(repository.onboardingDone.first())
        assertTrue(repository.autoGameMode.first())
        assertFalse(repository.landscapeFullscreen.first())
    }

    @Test
    fun writtenThemeModePersistsAndIsReadBack() = runBlocking {
        repository.setThemeMode(ZThemeMode.LIGHT)

        assertEquals(ZThemeMode.LIGHT, repository.themeMode.first())
    }

    @Test
    fun writtenPerformanceModePersistsAndIsReadBack() = runBlocking {
        repository.setPerformanceMode(ZPerformanceMode.HIGH_END)

        assertEquals(ZPerformanceMode.HIGH_END, repository.performanceMode.first())
    }

    @Test
    fun booleanTogglesRoundTripThroughRealDataStore() = runBlocking {
        repository.setReduceAnimation(true)
        repository.setOnboardingDone(true)
        repository.setKeepScreenOn(true)
        repository.setLandscapeFullscreen(true)

        assertTrue(repository.reduceAnimation.first())
        assertTrue(repository.onboardingDone.first())
        assertTrue(repository.keepScreenOn.first())
        assertTrue(repository.landscapeFullscreen.first())
    }

    @Test
    fun resetAllRestoresDefaultsAfterChanges() = runBlocking {
        repository.setThemeMode(ZThemeMode.LIGHT)
        repository.setDndEnabled(true)

        repository.resetAll()

        assertEquals(ZThemeMode.DARK, repository.themeMode.first())
        assertFalse(repository.dndEnabled.first())
    }
}
