package com.zbooster.app.util

import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.zbooster.app.ui.theme.ZPerformanceMode
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Instrumented test for the parts of [DeviceCapability] that genuinely need
 * a real Android [android.content.Context] (ActivityManager.MemoryInfo is
 * not available on a plain JVM). Requires a running emulator/device via
 * `./gradlew connectedAndroidTest`. The pure threshold math itself is
 * covered separately by the JVM unit test in `app/src/test/`.
 */
@RunWith(AndroidJUnit4::class)
class DeviceCapabilityInstrumentedTest {

    private val context = ApplicationProvider.getApplicationContext<android.content.Context>()

    @Test
    fun totalRamMbReturnsAPlausiblePositiveValue() {
        val totalRam = DeviceCapability.totalRamMb(context)

        // Any real device/emulator reports at least some positive MB figure;
        // this also guards against the try/catch fallback silently masking
        // a broken ActivityManager lookup.
        assertTrue("expected positive total RAM, got $totalRam", totalRam > 0)
    }

    @Test
    fun availableRamMbNeverExceedsTotalRamMb() {
        val total = DeviceCapability.totalRamMb(context)
        val available = DeviceCapability.availableRamMb(context)

        assertTrue(available in 0..total)
    }

    @Test
    fun ramUsagePercentIsWithinValidRange() {
        val usage = DeviceCapability.ramUsagePercent(context)

        assertTrue("usage percent out of range: $usage", usage in 0..100)
    }

    @Test
    fun resolveAutoPerformanceModeReturnsAConcreteNonAutoMode() {
        val resolved = DeviceCapability.resolveAutoPerformanceMode(context)

        // AUTO must always be resolved to a concrete mode for a real device;
        // it should never leak back out as ZPerformanceMode.AUTO itself.
        assertTrue(resolved != ZPerformanceMode.AUTO)
    }
}
