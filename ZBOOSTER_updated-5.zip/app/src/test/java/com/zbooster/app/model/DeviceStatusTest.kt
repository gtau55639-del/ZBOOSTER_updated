package com.zbooster.app.model

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pure JVM unit tests for [DeviceStatus.isGamingReady], which combines RAM
 * and battery thresholds (ramUsagePercent < 90 && batteryPercent > 15).
 */
class DeviceStatusTest {

    private fun status(ram: Int, battery: Int) = DeviceStatus(
        cpuUsagePercent = null,
        ramUsagePercent = ram,
        batteryPercent = battery,
        temperatureCelsius = null,
        isCharging = false
    )

    @Test
    fun `ready when ram under 90 percent and battery above 15 percent`() {
        assertTrue(status(ram = 50, battery = 50).isGamingReady)
    }

    @Test
    fun `not ready when ram usage is at or above 90 percent`() {
        assertFalse(status(ram = 90, battery = 50).isGamingReady)
        assertFalse(status(ram = 99, battery = 50).isGamingReady)
    }

    @Test
    fun `not ready when battery is at or below 15 percent`() {
        assertFalse(status(ram = 50, battery = 15).isGamingReady)
        assertFalse(status(ram = 50, battery = 5).isGamingReady)
    }

    @Test
    fun `boundary just inside both thresholds is ready`() {
        assertTrue(status(ram = 89, battery = 16).isGamingReady)
    }
}
