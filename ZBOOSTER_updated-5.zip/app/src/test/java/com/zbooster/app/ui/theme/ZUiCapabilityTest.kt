package com.zbooster.app.ui.theme

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pure JVM unit tests for [ZUiCapability]'s derived properties, which gate
 * animation richness across the app (spec STEP 11/12).
 */
class ZUiCapabilityTest {

    @Test
    fun `rich animation allowed by default on BALANCED with no reduce-motion`() {
        val capability = ZUiCapability(performanceMode = ZPerformanceMode.BALANCED, reduceMotion = false)
        assertTrue(capability.allowRichAnimation)
        assertEquals(260, capability.animationDurationMs)
    }

    @Test
    fun `LOW_END disables rich animation even without reduce-motion`() {
        val capability = ZUiCapability(performanceMode = ZPerformanceMode.LOW_END, reduceMotion = false)
        assertFalse(capability.allowRichAnimation)
        assertEquals(0, capability.animationDurationMs)
    }

    @Test
    fun `reduce-motion disables rich animation even on HIGH_END`() {
        val capability = ZUiCapability(performanceMode = ZPerformanceMode.HIGH_END, reduceMotion = true)
        assertFalse(capability.allowRichAnimation)
        assertEquals(0, capability.animationDurationMs)
    }

    @Test
    fun `HIGH_END without reduce-motion allows rich animation`() {
        val capability = ZUiCapability(performanceMode = ZPerformanceMode.HIGH_END, reduceMotion = false)
        assertTrue(capability.allowRichAnimation)
        assertEquals(260, capability.animationDurationMs)
    }
}
