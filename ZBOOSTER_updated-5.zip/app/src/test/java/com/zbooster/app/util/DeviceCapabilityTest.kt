package com.zbooster.app.util

import com.zbooster.app.ui.theme.ZPerformanceMode
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Pure JVM unit tests for [DeviceCapability.classifyRamMb] — the RAM->mode
 * threshold table used by [DeviceCapability.resolveAutoPerformanceMode].
 * No Android framework/Context involved, so this runs under `./gradlew test`
 * without an emulator.
 */
class DeviceCapabilityTest {

    @Test
    fun `unknown or non-positive ram falls back to BALANCED`() {
        assertEquals(ZPerformanceMode.BALANCED, DeviceCapability.classifyRamMb(0))
        assertEquals(ZPerformanceMode.BALANCED, DeviceCapability.classifyRamMb(-1))
    }

    @Test
    fun `low end range is classified as LOW_END`() {
        assertEquals(ZPerformanceMode.LOW_END, DeviceCapability.classifyRamMb(1))
        assertEquals(ZPerformanceMode.LOW_END, DeviceCapability.classifyRamMb(2048))
        assertEquals(ZPerformanceMode.LOW_END, DeviceCapability.classifyRamMb(3071))
    }

    @Test
    fun `balanced range boundaries are inclusive`() {
        assertEquals(ZPerformanceMode.BALANCED, DeviceCapability.classifyRamMb(3072))
        assertEquals(ZPerformanceMode.BALANCED, DeviceCapability.classifyRamMb(4096))
        assertEquals(ZPerformanceMode.BALANCED, DeviceCapability.classifyRamMb(6143))
    }

    @Test
    fun `high end starts at 6144 mb and has no upper bound`() {
        assertEquals(ZPerformanceMode.HIGH_END, DeviceCapability.classifyRamMb(6144))
        assertEquals(ZPerformanceMode.HIGH_END, DeviceCapability.classifyRamMb(16384))
        assertEquals(ZPerformanceMode.HIGH_END, DeviceCapability.classifyRamMb(Long.MAX_VALUE))
    }
}
