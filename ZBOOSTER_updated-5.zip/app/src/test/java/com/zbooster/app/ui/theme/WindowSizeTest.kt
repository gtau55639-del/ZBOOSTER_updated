package com.zbooster.app.ui.theme

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Pure JVM unit tests for the ZWindowSize breakpoint table (spec STEP 10).
 * These are plain Kotlin functions with no Android/Compose runtime
 * dependency, so they run under `./gradlew test`.
 */
class WindowSizeTest {

    @Test
    fun `widths below 400dp are COMPACT`() {
        assertEquals(ZWindowSize.COMPACT, widthDpToZWindowSize(320))
        assertEquals(ZWindowSize.COMPACT, widthDpToZWindowSize(399))
    }

    @Test
    fun `widths from 400dp up to but excluding 600dp are MEDIUM`() {
        assertEquals(ZWindowSize.MEDIUM, widthDpToZWindowSize(400))
        assertEquals(ZWindowSize.MEDIUM, widthDpToZWindowSize(500))
        assertEquals(ZWindowSize.MEDIUM, widthDpToZWindowSize(599))
    }

    @Test
    fun `widths of 600dp and above are EXPANDED`() {
        assertEquals(ZWindowSize.EXPANDED, widthDpToZWindowSize(600))
        assertEquals(ZWindowSize.EXPANDED, widthDpToZWindowSize(1024))
    }

    @Test
    fun `grid column counts match breakpoint`() {
        assertEquals(2, ZWindowSize.COMPACT.gameGridColumns())
        assertEquals(3, ZWindowSize.MEDIUM.gameGridColumns())
        assertEquals(5, ZWindowSize.EXPANDED.gameGridColumns())
    }

    @Test
    fun `content padding matches breakpoint`() {
        assertEquals(12, ZWindowSize.COMPACT.contentPadding())
        assertEquals(20, ZWindowSize.MEDIUM.contentPadding())
        assertEquals(32, ZWindowSize.EXPANDED.contentPadding())
    }
}
