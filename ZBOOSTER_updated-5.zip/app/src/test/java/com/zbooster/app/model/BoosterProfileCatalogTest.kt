package com.zbooster.app.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Guards against the catalog silently drifting out of sync with
 * [BoosterProfileType] as the app grows (e.g. someone adds a new enum
 * constant but forgets to add its [BoosterProfileInfo]).
 */
class BoosterProfileCatalogTest {

    @Test
    fun `catalog has exactly one entry per profile type`() {
        val types = boosterProfileCatalog.map { it.type }
        assertEquals(BoosterProfileType.entries.toSet(), types.toSet())
        assertEquals("no duplicate profile entries", types.size, types.toSet().size)
    }

    @Test
    fun `every catalog entry has non-blank title, description and emphasis`() {
        boosterProfileCatalog.forEach { info ->
            assertTrue("title blank for ${info.type}", info.title.isNotBlank())
            assertTrue("description blank for ${info.type}", info.description.isNotBlank())
            assertTrue("emphasis blank for ${info.type}", info.emphasis.isNotBlank())
        }
    }
}
