package com.zbooster.app.data.repository

import com.zbooster.app.data.local.GameMetadataEntity
import com.zbooster.app.model.BoosterProfileType
import com.zbooster.app.model.GameCategory
import com.zbooster.app.model.OptimizationStatus
import com.zbooster.app.util.InstalledAppsReader.InstalledApp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * Pure JVM unit tests for [GameRepository.mergeGamesWithMetadata] — merges a
 * fresh PackageManager scan with whatever ZBOOSTER metadata is stored in
 * Room. No Context, no Room database, no coroutines involved, so this runs
 * under `./gradlew test`.
 */
class GameRepositoryMergeTest {

    @Test
    fun `installed app with no stored metadata gets safe defaults`() {
        val installed = listOf(InstalledApp(packageName = "com.example.game", appName = "Example Game"))

        val result = GameRepository.mergeGamesWithMetadata(installed, emptyList())

        assertEquals(1, result.size)
        val game = result.first()
        assertEquals("com.example.game", game.packageName)
        assertEquals("Example Game", game.appName)
        assertEquals(false, game.isAddedToZBooster)
        assertEquals(false, game.isFavorite)
        assertEquals(GameCategory.ALL, game.category)
        assertEquals(BoosterProfileType.DEFAULT, game.boosterProfile)
        assertNull(game.lastPlayedTimestamp)
        assertEquals(OptimizationStatus.NOT_OPTIMIZED, game.optimizationStatus)
    }

    @Test
    fun `stored metadata is applied to the matching installed app`() {
        val installed = listOf(InstalledApp(packageName = "com.example.game", appName = "Example Game"))
        val metadata = listOf(
            GameMetadataEntity(
                packageName = "com.example.game",
                isAddedToZBooster = true,
                isFavorite = true,
                category = GameCategory.FAVORITE.name,
                boosterProfile = BoosterProfileType.EXTREME.name,
                lastPlayedTimestamp = 1_700_000_000_000L
            )
        )

        val game = GameRepository.mergeGamesWithMetadata(installed, metadata).single()

        assertEquals(true, game.isAddedToZBooster)
        assertEquals(true, game.isFavorite)
        assertEquals(GameCategory.FAVORITE, game.category)
        assertEquals(BoosterProfileType.EXTREME, game.boosterProfile)
        assertEquals(1_700_000_000_000L, game.lastPlayedTimestamp)
        assertEquals(OptimizationStatus.OPTIMIZED, game.optimizationStatus)
    }

    @Test
    fun `metadata for an uninstalled app is simply ignored, never crashes`() {
        val installed = listOf(InstalledApp(packageName = "com.example.game", appName = "Example Game"))
        val metadata = listOf(GameMetadataEntity(packageName = "com.example.uninstalled", isFavorite = true))

        val result = GameRepository.mergeGamesWithMetadata(installed, metadata)

        assertEquals(1, result.size)
        assertEquals(false, result.first().isFavorite)
    }

    @Test
    fun `corrupted category or profile string falls back to default instead of crashing`() {
        val installed = listOf(InstalledApp(packageName = "com.example.game", appName = "Example Game"))
        val metadata = listOf(
            GameMetadataEntity(
                packageName = "com.example.game",
                category = "NOT_A_REAL_CATEGORY",
                boosterProfile = "NOT_A_REAL_PROFILE"
            )
        )

        val game = GameRepository.mergeGamesWithMetadata(installed, metadata).single()

        assertEquals(GameCategory.ALL, game.category)
        assertEquals(BoosterProfileType.DEFAULT, game.boosterProfile)
    }

    @Test
    fun `empty installed list produces empty result regardless of metadata`() {
        val metadata = listOf(GameMetadataEntity(packageName = "com.example.game"))

        val result = GameRepository.mergeGamesWithMetadata(emptyList(), metadata)

        assertEquals(emptyList<Any>(), result)
    }
}
