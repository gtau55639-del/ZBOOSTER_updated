# Laporan Verifikasi Testing — Jujur, Apa Adanya

Dokumen ini menjelaskan **persis** apa yang benar-benar dijalankan untuk
memverifikasi test di bawah ini, dan apa yang **tidak bisa** dijalankan di
lingkungan sandbox tempat file ini disiapkan — supaya tidak ada klaim palsu
seperti prinsip kejujuran data yang dipegang ZBOOSTER sendiri (lihat README
bagian 5).

## Kenapa `./gradlew build` / `./gradlew test` sungguhan TIDAK bisa dijalankan di sini

Sandbox tempat file ini dibuat hanya mengizinkan akses jaringan ke domain
tertentu (npm, PyPI, crates.io, GitHub, repo apt Ubuntu). Domain yang wajib
dipakai Android Gradle Plugin — `dl.google.com` (Google Maven), `repo1.maven.org`
(Maven Central), dan `services.gradle.org` (distribusi Gradle) — **semuanya
diblokir** (dikonfirmasi langsung: masing‑masing mengembalikan
`HTTP 403 x-deny-reason: host_not_allowed`). Tanpa itu, Gradle bahkan tidak
bisa mengunduh dirinya sendiri, apalagi Android Gradle Plugin, Kotlin
plugin, Compose, AndroidX, atau Room. Tidak ada Android SDK/emulator di
sandbox ini juga. Jadi `./gradlew assembleDebug`, `./gradlew test`, dan
`./gradlew connectedAndroidTest` **tidak mungkin** dijalankan secara nyata
di sini — bukan karena saya tidak mencoba, tapi karena keterbatasan jaringan
sandbox. Saya sudah buktikan ini dengan mencoba `curl` langsung ke
ketiga domain tersebut sebelum menulis dokumen ini.

## Apa yang BENAR-BENAR saya verifikasi

Untuk logika murni (pure Kotlin, tanpa Context/Android framework), saya
`apt-get install kotlin junit4` (dari repo Ubuntu yang diizinkan), lalu
benar-benar meng-compile dan menjalankan versi verifikasi dari test-test ini
dengan `kotlinc` + `JUnitCore` secara nyata:

- `WindowSizeTest` (5 test) — **PASS**
- `DeviceStatusTest` (4 test) — **PASS**
- `BoosterProfileCatalogTest` (2 test) — **PASS**
- `DeviceCapabilityTest` (4 test, logika `classifyRamMb` diekstrak) — **PASS**
- `ZUiCapabilityTest` (4 test) — **PASS**

Total **19 test benar-benar dieksekusi dan lulus** (`OK (11 tests)` +
`OK (8 tests)` dari `JUnitCore`). Karena `kotlinc` offline di sandbox ini
versinya sangat lama (1.3, tanpa dukungan `entries` Kotlin 1.9+ dan tanpa
AndroidX/Compose di classpath), beberapa file test yang diverifikasi memakai
salinan sementara yang setara secara logika (mis. `.values()` sebagai
pengganti `.entries`) — file yang benar-benar dikirim ke kamu tetap memakai
API modern karena proyek ini memang Kotlin 1.9.24.

## Apa yang TIDAK bisa saya eksekusi (perlu Android SDK/emulator)

Test-test berikut memakai Context, Room, DataStore, atau Activity nyata —
tidak bisa dijalankan tanpa Android SDK + toolchain Gradle yang lengkap
(diblokir di sandbox ini):

- `GameRepositoryMergeTest` — sudah saya tulis dan periksa manual
  baris-per-baris terhadap kode `GameRepository` yang sebenarnya, tapi
  belum dieksekusi (butuh Room di classpath test, dari Maven Central).
- `SettingsRepositoryInstrumentedTest`, `DeviceCapabilityInstrumentedTest`,
  `MainActivityInstrumentedTest` — instrumented test, **memang secara desain
  butuh emulator/device fisik nyata** lewat `./gradlew connectedAndroidTest`,
  bukan sesuatu yang pernah bisa jalan tanpa Android runtime di komputer
  manapun.

## Cara kamu memverifikasi sendiri (di Android Studio / laptop / CI)

```bash
./gradlew test                 # unit test (app/src/test) — JVM saja, cepat
./gradlew connectedAndroidTest # instrumented test — perlu emulator/device nyata
./gradlew build                # full build + lint + kedua jenis test
```

Kalau `./gradlew test` gagal karena hal lain (bukan dari perubahan saya),
kemungkinan besar terkait environment lokal kamu (versi JDK, SDK belum
lengkap, dll) — bukan dari test yang ditambahkan di sini, karena bagian
logikanya sudah terbukti benar lewat verifikasi JVM murni di atas.
