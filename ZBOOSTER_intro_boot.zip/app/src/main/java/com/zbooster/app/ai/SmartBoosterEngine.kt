package com.zbooster.app.ai

import com.zbooster.app.model.BoosterProfileType
import com.zbooster.app.model.InsightSeverity
import com.zbooster.app.model.PerformanceSample
import com.zbooster.app.model.SmartInsight
import kotlin.math.roundToInt

/**
 * "AI Smart Booster" — a transparent, on-device, rule-based analysis
 * engine over the real [PerformanceSample] history ZBOOSTER has already
 * collected (RAM, battery, temperature, network, ping).
 *
 * This is deliberately NOT a black-box ML model shipped in the app or a
 * call to a cloud AI service: it is a small, auditable set of thresholds
 * over real numbers, every one of which is surfaced back to the user as
 * plain evidence. That keeps every claim this feature makes checkable and
 * avoids the two failure modes booster apps are usually criticized for —
 * (1) claiming impossible root-only effects, and (2) inventing
 * feel-good numbers with nothing real behind them (see BoosterProfileInfo
 * spec #18, InstalledAppsReader honesty comments — same philosophy here).
 *
 * All functions are pure (List<PerformanceSample> in, insight out) so
 * they're trivially unit-testable on the JVM with no Android framework
 * dependency.
 */
object SmartBoosterEngine {

    /** Need at least this many real samples before saying anything — never guess from 1-2 noisy readings. */
    private const val MIN_SAMPLES_FOR_INSIGHT = 4

    private const val HIGH_RAM_THRESHOLD = 85
    private const val HIGH_PING_MS = 100
    private const val LOW_BATTERY_THRESHOLD = 25
    private const val HOT_TEMPERATURE_C = 42f
    private const val WARM_TEMPERATURE_C = 38f

    fun analyze(history: List<PerformanceSample>): List<SmartInsight> {
        if (history.size < MIN_SAMPLES_FOR_INSIGHT) return emptyList()

        val recent = history.takeLast(10)
        return listOfNotNull(
            recommendProfile(recent),
            thermalAlert(recent),
            networkInsight(recent),
            batteryDrainInsight(recent)
        )
    }

    /**
     * Suggests a [BoosterProfileType] purely from measured averages —
     * exact same thresholds a human would eyeball on the Monitor Screen,
     * just automated. Always returns the real average(s) in [reason].
     */
    private fun recommendProfile(recent: List<PerformanceSample>): SmartInsight.ProfileRecommendation? {
        val avgRam = recent.map { it.ramUsagePercent }.average().roundToInt()
        val avgBattery = recent.map { it.batteryPercent }.average().roundToInt()
        val pings = recent.mapNotNull { it.pingMs }
        val avgPing = if (pings.isNotEmpty()) pings.average().roundToInt() else null

        return when {
            avgBattery <= LOW_BATTERY_THRESHOLD -> SmartInsight.ProfileRecommendation(
                profile = BoosterProfileType.BATTERY_SAVER,
                reason = "Battery averaged $avgBattery% over the last ${recent.size} checks — Battery Saver reduces ZBOOSTER's own background work to stretch what's left.",
                severity = InsightSeverity.IMPORTANT
            )
            avgRam >= HIGH_RAM_THRESHOLD && (avgPing == null || avgPing >= HIGH_PING_MS) -> SmartInsight.ProfileRecommendation(
                profile = BoosterProfileType.EXTREME,
                reason = buildString {
                    append("RAM averaged $avgRam% over the last ${recent.size} checks")
                    if (avgPing != null) append(" with ping averaging ${avgPing}ms")
                    append(" — Extreme applies every no-root optimization ZBOOSTER can to free up headroom.")
                },
                severity = InsightSeverity.SUGGESTED
            )
            avgRam >= HIGH_RAM_THRESHOLD -> SmartInsight.ProfileRecommendation(
                profile = BoosterProfileType.PERFORMANCE,
                reason = "RAM averaged $avgRam% over the last ${recent.size} checks — Performance mode trims ZBOOSTER's own footprint and keeps the screen on during play.",
                severity = InsightSeverity.SUGGESTED
            )
            avgRam < 60 && avgBattery > 50 -> SmartInsight.ProfileRecommendation(
                profile = BoosterProfileType.BALANCED,
                reason = "RAM ($avgRam%) and battery ($avgBattery%) both look healthy over the last ${recent.size} checks — Balanced is enough, no need to push Extreme.",
                severity = InsightSeverity.INFO
            )
            else -> null
        }
    }

    /**
     * Only fires on a REAL rising trend or a genuinely high absolute
     * reading — never on a single spike, and never at all if the device
     * doesn't expose temperature (returns null rather than a made-up figure).
     */
    private fun thermalAlert(recent: List<PerformanceSample>): SmartInsight.ThermalAlert? {
        val temps = recent.mapNotNull { it.temperatureCelsius }
        if (temps.size < MIN_SAMPLES_FOR_INSIGHT) return null

        val latest = temps.last()
        val trendRising = temps.last() - temps.first() >= 2f

        return when {
            latest >= HOT_TEMPERATURE_C -> SmartInsight.ThermalAlert(
                latestTemperatureCelsius = latest,
                reason = "Battery temperature reached ${latest}°C, the last of ${temps.size} readings. Consider a short break before your next match."
            )
            latest >= WARM_TEMPERATURE_C && trendRising -> SmartInsight.ThermalAlert(
                latestTemperatureCelsius = latest,
                reason = "Temperature climbed from ${temps.first()}°C to ${latest}°C over the last ${temps.size} readings — worth keeping an eye on."
            )
            else -> null
        }
    }

    /**
     * Compares real average ping on Wi-Fi vs Mobile data, ONLY when the
     * history actually contains at least a couple of real readings on
     * each network type — otherwise there's nothing honest to compare.
     */
    private fun networkInsight(recent: List<PerformanceSample>): SmartInsight.NetworkInsight? {
        val byNetwork = recent.filter { it.pingMs != null }.groupBy { it.networkType }
        val wifiPings = byNetwork["Wi-Fi"]?.mapNotNull { it.pingMs }.orEmpty()
        val mobilePings = byNetwork["Mobile Data"]?.mapNotNull { it.pingMs }.orEmpty()

        if (wifiPings.size < 2 || mobilePings.size < 2) return null

        val avgWifi = wifiPings.average().roundToInt()
        val avgMobile = mobilePings.average().roundToInt()
        if (avgMobile <= avgWifi) return null // only surface it when mobile is actually worse

        val delta = avgMobile - avgWifi
        return SmartInsight.NetworkInsight(
            reason = "Ping averages ${avgWifi}ms on Wi-Fi vs ${avgMobile}ms on Mobile data (+${delta}ms) across your recent checks — switch to Wi-Fi for competitive games when you can."
        )
    }

    /** Flags a real, measured battery drop across the session — not a projection, just what already happened. */
    private fun batteryDrainInsight(recent: List<PerformanceSample>): SmartInsight.BatteryDrainInsight? {
        if (recent.size < MIN_SAMPLES_FOR_INSIGHT) return null
        val first = recent.first()
        val last = recent.last()
        val elapsedMinutes = (last.timestampMs - first.timestampMs) / 60000f
        val drop = first.batteryPercent - last.batteryPercent

        if (elapsedMinutes < 3f || drop < 5) return null // too short/small a window to say anything meaningful

        val dropPerHour = (drop / elapsedMinutes) * 60f
        if (dropPerHour < 15f) return null // not an unusually fast drain

        return SmartInsight.BatteryDrainInsight(
            reason = "Battery dropped $drop% in about ${elapsedMinutes.roundToInt()} min (~${dropPerHour.roundToInt()}%/hr) this session — that's a fast drain for typical gaming."
        )
    }
}
