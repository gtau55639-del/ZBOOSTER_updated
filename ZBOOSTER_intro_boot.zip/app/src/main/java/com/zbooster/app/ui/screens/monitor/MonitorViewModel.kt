package com.zbooster.app.ui.screens.monitor

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zbooster.app.model.MonitorGraphMode
import com.zbooster.app.model.PerformanceSample
import com.zbooster.app.service.BoosterMonitorService
import com.zbooster.app.ui.theme.ZPerformanceMode
import com.zbooster.app.util.PerformanceSampler
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MonitorViewModel(application: Application) : AndroidViewModel(application) {

    private val _graphMode = MutableStateFlow(MonitorGraphMode.SIMPLE)
    val graphMode: StateFlow<MonitorGraphMode> = _graphMode.asStateFlow()

    private val _isLive = MutableStateFlow(false)
    val isLive: StateFlow<Boolean> = _isLive.asStateFlow()

    private val _history = MutableStateFlow<List<PerformanceSample>>(emptyList())
    val history: StateFlow<List<PerformanceSample>> = _history.asStateFlow()

    private val _latest = MutableStateFlow<PerformanceSample?>(null)
    val latest: StateFlow<PerformanceSample?> = _latest.asStateFlow()

    private var pollingJob: Job? = null

    // Shared with the AI Smart Booster on the Boost screen — see
    // ZBoosterApplication for why this lives at app scope, not here.
    private val historyRepository = (application as com.zbooster.app.ZBoosterApplication).performanceHistoryRepository

    fun setGraphMode(mode: MonitorGraphMode) {
        _graphMode.value = mode
    }

    /** Monitoring only runs when explicitly turned on (spec #11: no background polling by default). */
    fun toggleLive() {
        if (_isLive.value) stopLive() else startLive()
    }

    private fun startLive() {
        _isLive.value = true
        startMonitorService()
        pollingJob?.cancel()
        pollingJob = viewModelScope.launch {
            // Poll less frequently on constrained devices to save resources (spec #11).
            val autoMode = com.zbooster.app.util.DeviceCapability
                .resolveAutoPerformanceMode(getApplication())
            val intervalMs = if (autoMode == ZPerformanceMode.LOW_END) 4000L else 2000L

            while (true) {
                val sample = PerformanceSampler.sample(getApplication())
                _latest.value = sample
                _history.value = (_history.value + sample).takeLast(30)
                historyRepository.record(sample)
                delay(intervalMs)
            }
        }
    }

    private fun stopLive() {
        _isLive.value = false
        stopMonitorService()
        pollingJob?.cancel()
        pollingJob = null
    }

    /**
     * Starts the foreground [BoosterMonitorService] so Android doesn't kill
     * live monitoring while the user is actively watching this screen — and
     * so the required persistent notification is actually shown while it
     * runs (spec #11: never run a foreground service without a real reason).
     */
    private fun startMonitorService() {
        val context = getApplication<Application>()
        val intent = Intent(context, BoosterMonitorService::class.java).apply {
            action = BoosterMonitorService.ACTION_START
        }
        ContextCompat.startForegroundService(context, intent)
    }

    private fun stopMonitorService() {
        val context = getApplication<Application>()
        val intent = Intent(context, BoosterMonitorService::class.java).apply {
            action = BoosterMonitorService.ACTION_STOP
        }
        context.startService(intent)
    }

    override fun onCleared() {
        super.onCleared()
        if (_isLive.value) stopMonitorService()
        pollingJob?.cancel()
    }
}
