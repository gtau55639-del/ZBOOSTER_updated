package com.zbooster.app.data.repository

import com.zbooster.app.model.PerformanceSample
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * App-scoped (not screen-scoped) rolling buffer of real [PerformanceSample]s,
 * so "AI Smart Booster" insights on the Boost screen can see history even
 * if the user never opened the Monitor screen this session — and so
 * Monitor's own history survives navigating away and back.
 *
 * Deliberately in-memory only (cleared when the process dies): this is
 * session-level trend data for live suggestions, not a usage-tracking
 * feature, so nothing is written to disk (spec's permission/privacy
 * philosophy — collect only what's needed, for only as long as it's
 * needed).
 */
class PerformanceHistoryRepository {

    private val _history = MutableStateFlow<List<PerformanceSample>>(emptyList())
    val history: StateFlow<List<PerformanceSample>> = _history.asStateFlow()

    fun record(sample: PerformanceSample) {
        _history.value = (_history.value + sample).takeLast(MAX_SAMPLES)
    }

    companion object {
        private const val MAX_SAMPLES = 60
    }
}
