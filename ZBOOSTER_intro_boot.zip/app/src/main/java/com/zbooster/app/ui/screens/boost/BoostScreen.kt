@file:OptIn(ExperimentalMaterial3Api::class)

package com.zbooster.app.ui.screens.boost

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.outlined.BatteryAlert
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zbooster.app.model.BoosterProfileInfo
import com.zbooster.app.model.BoosterProfileType
import com.zbooster.app.model.InsightSeverity
import com.zbooster.app.model.SmartInsight
import com.zbooster.app.model.boosterProfileCatalog
import com.zbooster.app.ui.components.ZCard
import com.zbooster.app.ui.theme.*

@Composable
fun BoostScreen(viewModel: BoostViewModel = viewModel()) {
    val activeProfile by viewModel.activeProfile.collectAsStateWithLifecycle()
    val smartInsights by viewModel.smartInsights.collectAsStateWithLifecycle()
    val isScanning by viewModel.isScanning.collectAsStateWithLifecycle()
    val detectedGame by viewModel.detectedGame.collectAsStateWithLifecycle()
    val hasUsageAccess by viewModel.hasUsageAccess.collectAsStateWithLifecycle()

    var infoProfile by androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf<BoosterProfileInfo?>(null)
    }

    LaunchedEffect(Unit) { viewModel.refreshUsageAccessStatus() }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Boost Profiles",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Choose how ZBOOSTER balances performance and battery across the whole app.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ZTextSecondary
                )
            }
        }

        item {
            SmartBoosterSection(
                insights = smartInsights,
                isScanning = isScanning,
                detectedGame = detectedGame,
                hasUsageAccess = hasUsageAccess,
                onScan = viewModel::runQuickScan,
                onApplyProfile = viewModel::applyRecommendedProfile
            )
        }

        item {
            Text(
                text = "Profiles",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(boosterProfileCatalog, key = { it.type }) { info ->
            ProfileRow(
                info = info,
                isActive = activeProfile == info.type,
                onClick = { viewModel.selectProfile(info.type) },
                onChipClick = { infoProfile = info }
            )
        }
    }

    infoProfile?.let { info ->
        AlertDialog(
            onDismissRequest = { infoProfile = null },
            title = { Text(info.title) },
            text = { Text("${info.emphasis}: ${info.description}") },
            confirmButton = {
                TextButton(onClick = { infoProfile = null }) { Text("Got it") }
            }
        )
    }
}

/**
 * "AI Smart Booster" — on-device, rule-based insights over real collected
 * data (see ai/SmartBoosterEngine.kt). Deliberately transparent: every
 * insight card shows the real evidence behind it, and the section says so
 * plainly rather than implying a mystery cloud AI.
 */
@Composable
private fun SmartBoosterSection(
    insights: List<SmartInsight>,
    isScanning: Boolean,
    detectedGame: com.zbooster.app.model.DetectedGame?,
    hasUsageAccess: Boolean,
    onScan: () -> Unit,
    onApplyProfile: (BoosterProfileType) -> Unit
) {
    val context = LocalContext.current

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = ZSurfaceElevated,
        border = BorderStroke(1.dp, ZPurpleAccent.copy(alpha = 0.35f))
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Bolt, contentDescription = null, tint = ZPurpleAccent)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("AI Smart Booster", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "On-device analysis of your real usage — no cloud, nothing fabricated.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ZTextSecondary
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            Button(
                onClick = onScan,
                enabled = !isScanning,
                colors = ButtonDefaults.buttonColors(containerColor = ZPurpleAccent),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isScanning) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Scanning…")
                } else {
                    Text("Scan Now", fontWeight = FontWeight.Bold)
                }
            }

            if (!hasUsageAccess) {
                Spacer(Modifier.height(10.dp))
                UsageAccessPrompt(onOpenSettings = {
                    context.startActivity(com.zbooster.app.util.ForegroundAppDetector.usageAccessSettingsIntent())
                })
            }

            detectedGame?.let { game ->
                Spacer(Modifier.height(10.dp))
                DetectedGameCard(game)
            }

            if (insights.isEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    "Not enough real data yet — run the Monitor screen or tap Scan Now a few times first.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ZTextSecondary
                )
            } else {
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    insights.forEach { insight ->
                        InsightCard(insight = insight, onApplyProfile = onApplyProfile)
                    }
                }
            }
        }
    }
}

@Composable
private fun UsageAccessPrompt(onOpenSettings: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = ZSurface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.SportsEsports, contentDescription = null, tint = ZTextSecondary, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                "Enable Usage Access to let AI Smart Booster auto-detect which game you're playing.",
                style = MaterialTheme.typography.bodySmall,
                color = ZTextSecondary,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            TextButton(onClick = onOpenSettings) { Text("Enable") }
        }
    }
}

@Composable
private fun DetectedGameCard(game: com.zbooster.app.model.DetectedGame) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = ZCyberBlue.copy(alpha = 0.12f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.SportsEsports, contentDescription = null, tint = ZCyberBlue)
            Spacer(Modifier.width(8.dp))
            Column {
                Text("Detected: ${game.appName}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Currently using ${game.currentProfile.name.lowercase().replaceFirstChar { it.uppercase() }} profile",
                    style = MaterialTheme.typography.bodySmall,
                    color = ZTextSecondary
                )
            }
        }
    }
}

@Composable
private fun InsightCard(insight: SmartInsight, onApplyProfile: (BoosterProfileType) -> Unit) {
    val (icon, accent) = when (insight) {
        is SmartInsight.ProfileRecommendation -> Icons.Filled.Bolt to when (insight.severity) {
            InsightSeverity.IMPORTANT -> ZElectricRed
            InsightSeverity.SUGGESTED -> ZWarning
            InsightSeverity.INFO -> ZSuccess
        }
        is SmartInsight.ThermalAlert -> Icons.Filled.Thermostat to ZWarning
        is SmartInsight.NetworkInsight -> Icons.Filled.Wifi to ZCyberBlue
        is SmartInsight.BatteryDrainInsight -> Icons.Outlined.BatteryAlert to ZElectricRed
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = ZSurface,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(insight.reason, style = MaterialTheme.typography.bodySmall, color = ZTextPrimary)
                if (insight is SmartInsight.ProfileRecommendation) {
                    Spacer(Modifier.height(6.dp))
                    TextButton(
                        onClick = { onApplyProfile(insight.profile) },
                        contentPadding = PaddingValues(horizontal = 0.dp)
                    ) {
                        Text("Apply ${insight.profile.name.lowercase().replaceFirstChar { it.uppercase() }} profile", color = accent)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileRow(
    info: BoosterProfileInfo,
    isActive: Boolean,
    onClick: () -> Unit,
    onChipClick: () -> Unit
) {
    ZCard(modifier = Modifier.clickable(onClick = onClick)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(info.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    AssistChip(onClick = onChipClick, label = { Text(info.emphasis, style = MaterialTheme.typography.labelSmall) })
                }
                Spacer(Modifier.height(4.dp))
                Text(info.description, style = MaterialTheme.typography.bodyMedium, color = ZTextSecondary)
            }
            Spacer(Modifier.width(12.dp))
            Icon(
                imageVector = if (isActive) Icons.Filled.CheckCircle else Icons.Outlined.Circle,
                contentDescription = if (isActive) "Active" else "Inactive",
                tint = if (isActive) ZSuccess else ZTextSecondary
            )
        }
    }
}
