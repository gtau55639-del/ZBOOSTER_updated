package com.zbooster.app.ui.screens.intro

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseOutBack
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zbooster.app.ui.theme.ZBackground
import com.zbooster.app.ui.theme.ZCyberBlue
import com.zbooster.app.ui.theme.ZElectricRed
import com.zbooster.app.ui.theme.ZPurpleAccent
import com.zbooster.app.ui.theme.ZTextSecondary
import kotlinx.coroutines.delay

/**
 * Badass full-screen boot intro shown once per cold launch, before the
 * Loading screen — the "sangar" (fierce) ROG/RedMagic-style logo reveal
 * the user asked for: a punch-in wordmark, a sweeping diagonal energy
 * stripe, and a pulse-out shockwave ring, timed to land right when
 * [com.zbooster.app.util.BootSoundPlayer] fires the boot sound.
 *
 * On Low-End/Reduce-Animation devices this degrades to a much simpler,
 * shorter fade — same wordmark, no ring/stripe sweep — so it never costs
 * a low-end device a slow, janky launch (matches the rest of the app's
 * allowRichAnimation gating).
 */
@Composable
fun AppIntroScreen(
    allowRichAnimation: Boolean,
    onPlaySound: () -> Unit,
    onFinished: () -> Unit
) {
    val totalDurationMs = if (allowRichAnimation) 1700L else 700L

    val logoScale = remember { Animatable(if (allowRichAnimation) 0.4f else 0.85f) }
    val logoAlpha = remember { Animatable(0f) }
    val stripeProgress = remember { Animatable(0f) }
    val ringProgress = remember { Animatable(0f) }
    var soundFired by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        logoAlpha.animateTo(1f, tween(220, easing = LinearEasing))
        logoScale.animateTo(1f, tween(if (allowRichAnimation) 480 else 260, easing = EaseOutBack))

        if (!soundFired) {
            soundFired = true
            onPlaySound() // fire right as the logo lands, like a real power-on hit
        }

        if (allowRichAnimation) {
            stripeProgress.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
            ringProgress.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
        }

        delay(totalDurationMs - 480)
        onFinished()
    }

    val infiniteTransition = rememberInfiniteTransition(label = "introGlowPulse")
    val glowPulse by if (allowRichAnimation) {
        infiniteTransition.animateFloat(
            initialValue = 0.6f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(500, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "introGlowPulseAlpha"
        )
    } else {
        remember { mutableStateOf(1f) }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF1B0A10), ZBackground, Color.Black)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        if (allowRichAnimation) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Diagonal energy stripe sweeping across the whole screen.
                val sweepX = size.width * stripeProgress.value
                drawLine(
                    color = ZElectricRed.copy(alpha = 0.7f * glowPulse),
                    start = Offset(sweepX - 260f, 0f),
                    end = Offset(sweepX + 260f, size.height),
                    strokeWidth = 6f,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = ZCyberBlue.copy(alpha = 0.4f * glowPulse),
                    start = Offset(sweepX - 140f, 0f),
                    end = Offset(sweepX + 140f, size.height),
                    strokeWidth = 3f,
                    cap = StrokeCap.Round
                )

                // Expanding shockwave ring behind the logo.
                val maxRadius = size.minDimension * 0.65f
                val radius = maxRadius * ringProgress.value
                if (radius > 0f) {
                    drawCircle(
                        color = ZPurpleAccent.copy(alpha = (1f - ringProgress.value) * 0.8f),
                        radius = radius,
                        center = Offset(size.width / 2f, size.height / 2f),
                        style = Stroke(width = 4f)
                    )
                }
            }
        }

        Box(contentAlignment = Alignment.Center) {
            Text(
                text = "ZBOOSTER",
                fontSize = 42.sp,
                fontWeight = FontWeight.Black,
                color = ZElectricRed.copy(alpha = logoAlpha.value * glowPulse),
                modifier = Modifier
                    .align(Alignment.Center)
                    .scale(logoScale.value)
            )
        }
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
        Text(
            text = "NO ROOT · NO FAKE BOOST · JUST REAL PERFORMANCE",
            fontSize = 10.sp,
            letterSpacing = 1.5.sp,
            color = ZTextSecondary,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}
