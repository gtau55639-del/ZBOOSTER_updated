package com.zbooster.app.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import com.zbooster.app.R

/**
 * Plays the ZBOOSTER boot/intro sound effect exactly once when the app
 * launches. Deliberately respects the device's real ringer state — if the
 * user has their phone on Silent or Vibrate, [play] is a silent no-op
 * rather than forcing sound, matching Android platform conventions for
 * UI sound effects (same rule as e.g. keypress/navigation sounds).
 *
 * [SoundPool] (not MediaPlayer) is used because the clip is short (~1.3s)
 * and needs to start with near-zero latency right as the intro animation
 * begins.
 */
class BootSoundPlayer(private val context: Context) {

    private var soundPool: SoundPool? = null
    private var soundId: Int = 0
    private var loaded = false

    fun prepare() {
        if (soundPool != null) return
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val pool = SoundPool.Builder()
            .setMaxStreams(1)
            .setAudioAttributes(attributes)
            .build()
        pool.setOnLoadCompleteListener { _, _, status -> loaded = status == 0 }
        soundId = pool.load(context, R.raw.zbooster_boot, 1)
        soundPool = pool
    }

    /** Plays once if the clip finished loading and the device isn't silenced/vibrating. Never throws. */
    fun play() {
        try {
            if (!loaded) return
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            if (audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
            soundPool?.play(soundId, 1f, 1f, 1, 0, 1f)
        } catch (e: Exception) {
            // Never let a decorative sound effect crash app launch.
        }
    }

    fun release() {
        soundPool?.release()
        soundPool = null
        loaded = false
    }
}
