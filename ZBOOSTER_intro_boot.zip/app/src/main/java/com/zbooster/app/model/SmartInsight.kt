package com.zbooster.app.model

/**
 * Output of [com.zbooster.app.ai.SmartBoosterEngine] — the "AI Smart
 * Booster" feature.
 *
 * Design rule (matches the rest of ZBOOSTER's honesty spec, e.g. #18 on
 * BoosterProfileInfo): every insight here is a plain, explainable
 * rule-based analysis of REAL [PerformanceSample]s already collected on
 * this device — never a black-box guess, never a fabricated number, and
 * never presented when there isn't enough real data to support it. Each
 * insight always carries the concrete evidence ([reason]) that produced
 * it, so the user can see exactly why the app is suggesting something.
 */
sealed class SmartInsight {

    /** The evidence-backed sentence shown under every insight, e.g. "RAM averaged 88% over the last 6 checks." */
    abstract val reason: String

    data class ProfileRecommendation(
        val profile: BoosterProfileType,
        override val reason: String,
        val severity: InsightSeverity
    ) : SmartInsight()

    data class ThermalAlert(
        val latestTemperatureCelsius: Float,
        override val reason: String
    ) : SmartInsight()

    data class NetworkInsight(
        override val reason: String
    ) : SmartInsight()

    data class BatteryDrainInsight(
        override val reason: String
    ) : SmartInsight()
}

enum class InsightSeverity { INFO, SUGGESTED, IMPORTANT }

/** A game the on-device Foreground Detector believes is currently running, matched against the real installed-games scan. */
data class DetectedGame(
    val packageName: String,
    val appName: String,
    val currentProfile: BoosterProfileType
)
