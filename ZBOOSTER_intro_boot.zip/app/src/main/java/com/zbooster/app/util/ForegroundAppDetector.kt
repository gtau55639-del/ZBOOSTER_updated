package com.zbooster.app.util

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Process
import android.provider.Settings

/**
 * Detects which app is currently in the foreground, for the AI Smart
 * Booster's "auto-detect game" insight.
 *
 * Android has no public, permission-free API for "what app is in front
 * right now" — the only real (non-root) source is [UsageStatsManager],
 * which requires the user to manually grant the special "Usage Access"
 * permission in system Settings (Android has no runtime-permission
 * dialog for it; this matches how every legitimate game-booster app on
 * Play requests it). ZBOOSTER never assumes this is granted, never
 * fakes a result if it isn't, and only checks foreground app on-demand
 * (a user-triggered scan) rather than polling in the background — no
 * silent, continuous app-usage snooping (spec's permission philosophy).
 */
object ForegroundAppDetector {

    fun hasUsageAccessPermission(context: Context): Boolean {
        return try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
            mode == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }
    }

    fun usageAccessSettingsIntent(): Intent =
        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)

    /**
     * Returns the package name most recently brought to the foreground,
     * looking back a short window (default 10s) via real UsageEvents —
     * or null if permission isn't granted, nothing qualifies, or the
     * lookup fails for any reason. Never guesses.
     */
    fun currentForegroundPackage(context: Context, lookbackMs: Long = 10_000L): String? {
        if (!hasUsageAccessPermission(context)) return null
        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
                ?: return null
            val end = System.currentTimeMillis()
            val start = end - lookbackMs
            val events = usm.queryEvents(start, end)
            var lastForegroundPackage: String? = null
            val event = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                    lastForegroundPackage = event.packageName
                }
            }
            lastForegroundPackage
        } catch (e: Exception) {
            null
        }
    }
}
