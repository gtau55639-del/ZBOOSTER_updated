package com.zbooster.app.ui.screens.intro

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zbooster.app.ui.theme.ZBackground
import com.zbooster.app.ui.theme.ZCyberBlue
import com.zbooster.app.ui.theme.ZElectricRed
import com.zbooster.app.ui.theme.ZSurface
import com.zbooster.app.ui.theme.ZTextSecondary

/**
 * Brief full-screen loading state shown right after [AppIntroScreen],
 * while real app state (DataStore preferences, onboarding flag) finishes
 * loading. Styled to match the same gaming-HUD identity rather than a
 * generic system spinner.
 */
@Composable
fun LoadingScreen(allowRichAnimation: Boolean, label: String = "Loading ZBOOSTER…") {
    val infiniteTransition = rememberInfiniteTransition(label = "loadingBarSweep")
    val progress by if (allowRichAnimation) {
        infiniteTransition.animateFloat(
            initialValue = 0.08f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(900, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "loadingBarProgress"
        )
    } else {
        remember { mutableStateOf(0.6f) }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ZBackground),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = ZTextSecondary
            )
            Spacer(Modifier.height(16.dp))
            Box(
                modifier = Modifier
                    .width(160.dp)
                    .height(6.dp)
                    .clip(RoundedCornerShape(50))
                    .background(ZSurface)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress)
                        .fillMaxSize()
                        .clip(RoundedCornerShape(50))
                        .background(
                            Brush.horizontalGradient(listOf(ZElectricRed, ZCyberBlue))
                        )
                )
            }
        }
    }
}
