package com.zbooster.app.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.zbooster.app.ui.theme.ZPerformanceMode
import com.zbooster.app.ui.theme.ZThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "zbooster_settings")

/**
 * Central place for all persisted user preferences (spec STEP 9 Settings).
 * Backed by Jetpack DataStore (not SharedPreferences) as required.
 */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val PERFORMANCE_MODE = stringPreferencesKey("performance_mode")
        val REDUCE_ANIMATION = booleanPreferencesKey("reduce_animation")
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
        val AUTO_GAME_MODE = booleanPreferencesKey("auto_game_mode")
        val DND_ENABLED = booleanPreferencesKey("dnd_enabled")
        val OVERLAY_ENABLED = booleanPreferencesKey("overlay_enabled")
        val KEEP_SCREEN_ON = booleanPreferencesKey("keep_screen_on")
        val LANDSCAPE_FULLSCREEN = booleanPreferencesKey("landscape_fullscreen")
        val INTRO_SOUND_ENABLED = booleanPreferencesKey("intro_sound_enabled")
    }

    val themeMode: Flow<ZThemeMode> = context.dataStore.data.map { prefs ->
        runCatching { ZThemeMode.valueOf(prefs[Keys.THEME_MODE] ?: ZThemeMode.DARK.name) }
            .getOrDefault(ZThemeMode.DARK)
    }

    val performanceMode: Flow<ZPerformanceMode> = context.dataStore.data.map { prefs ->
        runCatching { ZPerformanceMode.valueOf(prefs[Keys.PERFORMANCE_MODE] ?: ZPerformanceMode.AUTO.name) }
            .getOrDefault(ZPerformanceMode.AUTO)
    }

    val reduceAnimation: Flow<Boolean> = context.dataStore.data.map { it[Keys.REDUCE_ANIMATION] ?: false }
    val onboardingDone: Flow<Boolean> = context.dataStore.data.map { it[Keys.ONBOARDING_DONE] ?: false }
    val autoGameMode: Flow<Boolean> = context.dataStore.data.map { it[Keys.AUTO_GAME_MODE] ?: true }
    val dndEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.DND_ENABLED] ?: false }
    val overlayEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.OVERLAY_ENABLED] ?: false }
    val keepScreenOn: Flow<Boolean> = context.dataStore.data.map { it[Keys.KEEP_SCREEN_ON] ?: false }
    val landscapeFullscreen: Flow<Boolean> = context.dataStore.data.map { it[Keys.LANDSCAPE_FULLSCREEN] ?: false }
    val introSoundEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.INTRO_SOUND_ENABLED] ?: true }

    suspend fun setThemeMode(mode: ZThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setPerformanceMode(mode: ZPerformanceMode) {
        context.dataStore.edit { it[Keys.PERFORMANCE_MODE] = mode.name }
    }

    suspend fun setReduceAnimation(enabled: Boolean) {
        context.dataStore.edit { it[Keys.REDUCE_ANIMATION] = enabled }
    }

    suspend fun setOnboardingDone(done: Boolean) {
        context.dataStore.edit { it[Keys.ONBOARDING_DONE] = done }
    }

    suspend fun setAutoGameMode(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_GAME_MODE] = enabled }
    }

    suspend fun setDndEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DND_ENABLED] = enabled }
    }

    suspend fun setOverlayEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.OVERLAY_ENABLED] = enabled }
    }

    suspend fun setKeepScreenOn(enabled: Boolean) {
        context.dataStore.edit { it[Keys.KEEP_SCREEN_ON] = enabled }
    }

    suspend fun setLandscapeFullscreen(enabled: Boolean) {
        context.dataStore.edit { it[Keys.LANDSCAPE_FULLSCREEN] = enabled }
    }

    suspend fun setIntroSoundEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.INTRO_SOUND_ENABLED] = enabled }
    }

    suspend fun resetAll() {
        context.dataStore.edit { it.clear() }
    }
}
