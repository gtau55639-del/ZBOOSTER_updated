package com.zbooster.app.ui.screens.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zbooster.app.ui.theme.ZPerformanceMode
import com.zbooster.app.ui.theme.ZThemeMode
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = (application as com.zbooster.app.ZBoosterApplication).settingsRepository

    val themeMode: StateFlow<ZThemeMode> =
        repo.themeMode.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ZThemeMode.DARK)

    val performanceMode: StateFlow<ZPerformanceMode> =
        repo.performanceMode.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ZPerformanceMode.AUTO)

    val reduceAnimation: StateFlow<Boolean> =
        repo.reduceAnimation.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val autoGameMode: StateFlow<Boolean> =
        repo.autoGameMode.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val dndEnabled: StateFlow<Boolean> =
        repo.dndEnabled.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val overlayEnabled: StateFlow<Boolean> =
        repo.overlayEnabled.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val keepScreenOn: StateFlow<Boolean> =
        repo.keepScreenOn.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val landscapeFullscreen: StateFlow<Boolean> =
        repo.landscapeFullscreen.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val introSoundEnabled: StateFlow<Boolean> =
        repo.introSoundEnabled.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    fun setThemeMode(mode: ZThemeMode) = viewModelScope.launch { repo.setThemeMode(mode) }
    fun setPerformanceMode(mode: ZPerformanceMode) = viewModelScope.launch { repo.setPerformanceMode(mode) }
    fun setReduceAnimation(v: Boolean) = viewModelScope.launch { repo.setReduceAnimation(v) }
    fun setAutoGameMode(v: Boolean) = viewModelScope.launch { repo.setAutoGameMode(v) }
    fun setDndEnabled(v: Boolean) = viewModelScope.launch { repo.setDndEnabled(v) }
    fun setOverlayEnabled(v: Boolean) = viewModelScope.launch { repo.setOverlayEnabled(v) }
    fun setKeepScreenOn(v: Boolean) = viewModelScope.launch { repo.setKeepScreenOn(v) }
    fun setLandscapeFullscreen(v: Boolean) = viewModelScope.launch { repo.setLandscapeFullscreen(v) }
    fun setIntroSoundEnabled(v: Boolean) = viewModelScope.launch { repo.setIntroSoundEnabled(v) }

    fun resetAll() = viewModelScope.launch { repo.resetAll() }
}
