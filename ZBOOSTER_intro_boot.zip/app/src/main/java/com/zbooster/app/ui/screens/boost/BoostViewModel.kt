package com.zbooster.app.ui.screens.boost

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zbooster.app.ai.SmartBoosterEngine
import com.zbooster.app.model.BoosterProfileType
import com.zbooster.app.model.DetectedGame
import com.zbooster.app.model.SmartInsight
import com.zbooster.app.util.ForegroundAppDetector
import com.zbooster.app.util.PerformanceSampler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BoostViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepository = (application as com.zbooster.app.ZBoosterApplication).settingsRepository
    private val gameRepository = (application as com.zbooster.app.ZBoosterApplication).gameRepository
    private val historyRepository = (application as com.zbooster.app.ZBoosterApplication).performanceHistoryRepository

    // Reuses the existing performanceMode preference as the "active global
    // profile" concept requested by spec STEP 6, keeping a single source of
    // truth instead of a second, redundant DataStore key.
    val activeProfile: StateFlow<BoosterProfileType> = settingsRepository.performanceMode
        .map { perfMode ->
            when (perfMode) {
                com.zbooster.app.ui.theme.ZPerformanceMode.LOW_END -> BoosterProfileType.BATTERY_SAVER
                com.zbooster.app.ui.theme.ZPerformanceMode.HIGH_END -> BoosterProfileType.PERFORMANCE
                com.zbooster.app.ui.theme.ZPerformanceMode.BALANCED -> BoosterProfileType.BALANCED
                com.zbooster.app.ui.theme.ZPerformanceMode.AUTO -> BoosterProfileType.DEFAULT
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BoosterProfileType.DEFAULT)

    // --- AI Smart Booster --------------------------------------------------
    // See ai/SmartBoosterEngine.kt for the honesty rules this is built on:
    // rule-based over REAL collected samples, never a black box, never
    // shown until there's enough real data to back it.

    val smartInsights: StateFlow<List<SmartInsight>> = historyRepository.history
        .map { SmartBoosterEngine.analyze(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _detectedGame = MutableStateFlow<DetectedGame?>(null)
    val detectedGame: StateFlow<DetectedGame?> = _detectedGame.asStateFlow()

    private val _hasUsageAccess = MutableStateFlow(false)
    val hasUsageAccess: StateFlow<Boolean> = _hasUsageAccess.asStateFlow()

    /** Call from the screen (e.g. on first composition / resume) — cheap AppOps check, no I/O. */
    fun refreshUsageAccessStatus() {
        _hasUsageAccess.value = ForegroundAppDetector.hasUsageAccessPermission(getApplication())
    }

    /**
     * User-triggered "Scan Now": takes ONE real performance sample (feeds
     * the shared history so insights above have real data to work with)
     * and, only if Usage Access is granted, checks the real foreground
     * app against the real installed-games scan. Deliberately not a
     * background poller — see ForegroundAppDetector doc comment.
     */
    fun runQuickScan() {
        if (_isScanning.value) return
        viewModelScope.launch {
            _isScanning.value = true
            try {
                val sample = PerformanceSampler.sample(getApplication())
                historyRepository.record(sample)
                detectForegroundGame()
            } finally {
                _isScanning.value = false
            }
        }
    }

    private suspend fun detectForegroundGame() {
        _detectedGame.value = null
        val foregroundPackage = ForegroundAppDetector.currentForegroundPackage(getApplication()) ?: return
        val installedGames = gameRepository.refreshInstalledGamesOnce()
        val match = installedGames.firstOrNull { it.packageName == foregroundPackage } ?: return
        gameRepository.markLaunched(match.packageName)
        _detectedGame.value = DetectedGame(
            packageName = match.packageName,
            appName = match.appName,
            currentProfile = activeProfile.value
        )
    }

    fun selectProfile(profile: BoosterProfileType) {
        viewModelScope.launch {
            val mappedPerfMode = when (profile) {
                BoosterProfileType.BATTERY_SAVER -> com.zbooster.app.ui.theme.ZPerformanceMode.LOW_END
                BoosterProfileType.PERFORMANCE, BoosterProfileType.EXTREME -> com.zbooster.app.ui.theme.ZPerformanceMode.HIGH_END
                BoosterProfileType.BALANCED -> com.zbooster.app.ui.theme.ZPerformanceMode.BALANCED
                BoosterProfileType.DEFAULT, BoosterProfileType.CUSTOM -> com.zbooster.app.ui.theme.ZPerformanceMode.AUTO
            }
            settingsRepository.setPerformanceMode(mappedPerfMode)
        }
    }

    /** Applies an AI-recommended profile — same effect as tapping it manually in the list. */
    fun applyRecommendedProfile(profile: BoosterProfileType) = selectProfile(profile)
}
