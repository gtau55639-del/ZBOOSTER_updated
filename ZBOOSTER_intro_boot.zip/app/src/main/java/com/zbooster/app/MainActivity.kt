package com.zbooster.app

import android.app.NotificationManager
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.zbooster.app.ui.navigation.ZNavHost
import com.zbooster.app.ui.screens.intro.AppIntroScreen
import com.zbooster.app.ui.screens.intro.LoadingScreen
import com.zbooster.app.ui.screens.onboarding.OnboardingScreen
import com.zbooster.app.ui.theme.ZBoosterTheme
import com.zbooster.app.ui.theme.ZPerformanceMode
import com.zbooster.app.ui.theme.ZThemeMode
import com.zbooster.app.ui.theme.ZUiCapability
import com.zbooster.app.ui.theme.widthDpToZWindowSize
import com.zbooster.app.util.BootSoundPlayer
import com.zbooster.app.util.DeviceCapability
import com.zbooster.app.util.PermissionHelper
import kotlinx.coroutines.launch

/** Cold-launch flow: badass intro animation (+ sound) -> brief loading state -> real app content. */
private enum class AppLaunchStage { INTRO, LOADING, READY }

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ZBoosterApp(activity = this)
        }
    }
}

@Composable
private fun ZBoosterApp(activity: ComponentActivity) {
    val app = activity.application as ZBoosterApplication
    val settingsRepo = app.settingsRepository
    val context = LocalContext.current

    val themeMode by settingsRepo.themeMode.collectAsState(initial = ZThemeMode.DARK)
    val storedPerformanceMode by settingsRepo.performanceMode.collectAsState(initial = ZPerformanceMode.AUTO)
    val reduceAnimation by settingsRepo.reduceAnimation.collectAsState(initial = false)
    val introSoundEnabled by settingsRepo.introSoundEnabled.collectAsState(initial = true)
    // Nullable so we can distinguish "not loaded yet" from "loaded, not done" —
    // otherwise the onboarding flow would briefly flash on every app start.
    val onboardingDone by produceState<Boolean?>(initialValue = null) {
        settingsRepo.onboardingDone.collect { value = it }
    }
    val scope = rememberCoroutineScope()

    // Boot sound: prepared once for this Activity's lifetime, released when
    // it's destroyed. Playing it is entirely optional and gated by the
    // "Boot Intro Sound" Settings toggle plus the device's real ringer
    // state (see BootSoundPlayer.play doc comment) — never forced.
    val bootSoundPlayer = remember { BootSoundPlayer(context) }
    DisposableEffect(Unit) {
        bootSoundPlayer.prepare()
        onDispose { bootSoundPlayer.release() }
    }

    var launchStage by remember { mutableStateOf(AppLaunchStage.INTRO) }

    // Keep Screen On (Settings > Gameplay): actually flips the window flag,
    // reactively, wherever the app is currently open — not just a stored
    // boolean. Cleared automatically when the setting is turned off or the
    // Activity is destroyed (LaunchedEffect disposal).
    val keepScreenOn by settingsRepo.keepScreenOn.collectAsState(initial = false)
    LaunchedEffect(keepScreenOn) {
        if (keepScreenOn) {
            activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // Landscape + Fullscreen (Settings > Gameplay): locks orientation to
    // landscape (either rotation, via the device sensor) and hides the
    // status/navigation bars for an immersive gaming layout. Bars can still
    // be revealed with a swipe (BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE) so the
    // user is never fully locked out of system UI. Reverted automatically
    // when the setting is turned off or the Activity is destroyed.
    val landscapeFullscreen by settingsRepo.landscapeFullscreen.collectAsState(initial = false)
    LaunchedEffect(landscapeFullscreen) {
        val insetsController = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        if (landscapeFullscreen) {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            insetsController.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            insetsController.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            insetsController.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // Do Not Disturb (Settings > Gameplay): actually flips the system
    // interruption filter, but only when the OS confirms DND access is
    // granted — otherwise this is a silent no-op rather than a crash.
    val dndEnabled by settingsRepo.dndEnabled.collectAsState(initial = false)
    LaunchedEffect(dndEnabled) {
        if (PermissionHelper.hasDndAccess(activity)) {
            val manager = activity.getSystemService(NotificationManager::class.java)
            manager?.setInterruptionFilter(
                if (dndEnabled) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                else NotificationManager.INTERRUPTION_FILTER_ALL
            )
        }
    }

    val resolvedPerformanceMode =
        if (storedPerformanceMode == ZPerformanceMode.AUTO) {
            DeviceCapability.resolveAutoPerformanceMode(activity)
        } else {
            storedPerformanceMode
        }

    val uiCapability = ZUiCapability(
        performanceMode = resolvedPerformanceMode,
        reduceMotion = reduceAnimation
    )

    // Raw current width in dp drives our own COMPACT/MEDIUM/EXPANDED
    // breakpoints (spec STEP 10) and updates on rotation/fold via configChanges.
    val zWindowSize = widthDpToZWindowSize(activity.resources.configuration.screenWidthDp)

    ZBoosterTheme(themeMode = themeMode, uiCapability = uiCapability) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Box(Modifier.fillMaxSize()) {
                when (launchStage) {
                    AppLaunchStage.INTRO -> AppIntroScreen(
                        allowRichAnimation = uiCapability.allowRichAnimation,
                        onPlaySound = {
                            if (introSoundEnabled) bootSoundPlayer.play()
                        },
                        onFinished = { launchStage = AppLaunchStage.LOADING }
                    )
                    AppLaunchStage.LOADING -> {
                        LoadingScreen(allowRichAnimation = uiCapability.allowRichAnimation)
                        // Moves on as soon as real preference/onboarding data has
                        // actually loaded — never a fixed fake delay, just a
                        // minimum so the transition doesn't look like a flicker.
                        LaunchedEffect(onboardingDone) {
                            if (onboardingDone != null) {
                                kotlinx.coroutines.delay(400)
                                launchStage = AppLaunchStage.READY
                            }
                        }
                    }
                    AppLaunchStage.READY -> when (onboardingDone) {
                        false -> OnboardingScreen(
                            onFinished = {
                                scope.launch { settingsRepo.setOnboardingDone(true) }
                            }
                        )
                        else -> ZNavHost(windowSize = zWindowSize)
                    }
                }
            }
        }
    }
}
