# Release Keystore — ZBOOSTER

This folder contains the **real signing key** used to publish ZBOOSTER to
Google Play. This is different from `app/debug.keystore` (which only signs
debug/test builds and is safe to commit).

## Files here
- `zbooster-release.jks` — the actual keystore (a cryptographic key file)
- `CREDENTIALS_DO_NOT_COMMIT.txt` — the passwords for that keystore

## ⚠️ Critical rules
1. **Never commit `zbooster-release.jks` or `CREDENTIALS_DO_NOT_COMMIT.txt` to Git**,
   public or private repo. `.gitignore` already excludes them — don't override that.
2. **Back this up somewhere safe** (a password manager, encrypted drive, or
   Google's own "Play App Signing" upload-key system). If you lose this file,
   **you can never publish an update to your existing Play Store listing again**
   — Google would force you to publish as a brand-new app, losing all reviews,
   installs, and ratings.
3. If you use GitHub Actions to build your release AAB/APK, **do not put these
   values directly in the workflow file**. Instead:
   - Go to your GitHub repo → **Settings → Secrets and variables → Actions**
   - Add secrets: `KEYSTORE_BASE64` (the .jks file, base64-encoded),
     `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`
   - In your workflow, decode the secret back into a file before the build step, e.g.:
     ```yaml
     - name: Decode keystore
       run: echo "${{ secrets.KEYSTORE_BASE64 }}" | base64 -d > keystore-release/zbooster-release.jks
     - name: Write keystore.properties
       run: |
         echo "storeFile=../keystore-release/zbooster-release.jks" > keystore.properties
         echo "storePassword=${{ secrets.KEYSTORE_PASSWORD }}" >> keystore.properties
         echo "keyAlias=${{ secrets.KEY_ALIAS }}" >> keystore.properties
         echo "keyPassword=${{ secrets.KEY_PASSWORD }}" >> keystore.properties
     ```
   To get the base64 value: run `base64 -w0 zbooster-release.jks` (Linux/Mac)
   or `certutil -encode zbooster-release.jks tmp.b64` (Windows) and copy the output.

## Building a signed release locally
```
./gradlew assembleRelease
```
Output: `app/build/outputs/apk/release/app-release.apk` (or use `bundleRelease`
for the `.aab` that Play Console requires for new app submissions).
