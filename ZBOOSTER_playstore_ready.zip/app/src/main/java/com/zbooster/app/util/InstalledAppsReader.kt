package com.zbooster.app.util

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

/**
 * Reads installed applications through the standard PackageManager API
 * (spec #5: "Membaca aplikasi yang relevan melalui package manager sesuai
 * permission Android yang tersedia"). No hidden/private API is used.
 *
 * Uses Android 11+ scoped package visibility (the <queries> block in
 * AndroidManifest matching ACTION_MAIN/CATEGORY_LAUNCHER) rather than the
 * QUERY_ALL_PACKAGES permission. This still surfaces virtually every
 * normal, user-installed app — including all games, since any app with a
 * launcher icon matches this filter — while avoiding the broad
 * "see every package on the device" access that Google Play scrutinizes
 * heavily and often rejects apps for using without a very strong case.
 *
 * Game detection heuristic (best-effort, not perfect — Android has no
 * single authoritative "is this a game" flag for every app):
 *   1. ApplicationInfo.category == CATEGORY_GAME (reliable when the
 *      developer declared it, API 26+) / legacy FLAG_IS_GAME pre-API 26.
 *   2. Fallback: the app's native library directory contains a shared
 *      library from a well-known game engine (Unity, Unreal, Cocos2d,
 *      Godot). Many real, popular games never set the category flag, so
 *      this fallback substantially improves recall in the Game Library.
 * Apps that match neither signal are simply excluded — we never guess and
 * mislabel a random app as a "game". Note this is still not exhaustive:
 * some games (especially 2D/web-view based ones) use no native engine
 * library and no category flag, and will not be detected.
 */
object InstalledAppsReader {

    data class InstalledApp(
        val packageName: String,
        val appName: String
    )

    fun getInstalledGames(context: Context): List<InstalledApp> {
        val pm = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)

        val launchablePackageNames: List<String> = try {
            pm.queryIntentActivities(launcherIntent, 0)
                .mapNotNull { it.activityInfo?.packageName }
                .distinct()
        } catch (e: Exception) {
            emptyList()
        }

        return launchablePackageNames
            .asSequence()
            .mapNotNull { pkg ->
                try {
                    pm.getApplicationInfo(pkg, PackageManager.GET_META_DATA)
                } catch (e: Exception) {
                    null // app matched the launcher query but details aren't visible/readable; skip it
                }
            }
            .filter { isLikelyGame(it) }
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null } // must be launchable
            .mapNotNull { appInfo ->
                val label = try {
                    pm.getApplicationLabel(appInfo)?.toString()
                } catch (e: Exception) {
                    null
                }
                label?.let { InstalledApp(appInfo.packageName, it) }
            }
            .distinctBy { it.packageName }
            .sortedBy { it.appName.lowercase() }
            .toList()
    }

    // Shared native libraries that only ship inside game engines. If any of
    // these show up in an app's native library directory, the app is
    // overwhelmingly likely to be a game even when the developer never set
    // android:appCategory="game" in their manifest (a very common omission
    // in practice, which is why CATEGORY_GAME alone misses many real games).
    private val GAME_ENGINE_NATIVE_LIBS = listOf(
        "libunity.so",
        "libil2cpp.so",
        "libcocos2dcpp.so",
        "libcocos2dlua.so",
        "libUE4.so",
        "libUnreal.so",
        "libgodot_android.so",
        "libGodot.so"
    )

    @Suppress("DEPRECATION")
    private fun isLikelyGame(appInfo: ApplicationInfo): Boolean {
        // Skip system apps that are extremely unlikely to be games
        val isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
        if (isSystemApp) return false

        val declaredAsGame = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            appInfo.category == ApplicationInfo.CATEGORY_GAME
        } else {
            // Legacy flag, deprecated but still the only signal pre-API 26
            (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0
        }
        if (declaredAsGame) return true

        // Fallback heuristic for the many real-world games that never set
        // the category flag. Best-effort only: reading another app's native
        // library directory can fail or be empty depending on OEM/Android
        // version, so any failure here just means "not detected", never a
        // crash — consistent with spec's "no permission escalation" rule
        // (this only reads packages already made visible via the <queries>
        // launcher-intent filter declared in AndroidManifest).
        return runCatching { hasGameEngineNativeLibs(appInfo) }.getOrDefault(false)
    }

    private fun hasGameEngineNativeLibs(appInfo: ApplicationInfo): Boolean {
        val libDir = appInfo.nativeLibraryDir ?: return false
        val dir = java.io.File(libDir)
        val files = dir.listFiles() ?: return false
        return files.any { it.name in GAME_ENGINE_NATIVE_LIBS }
    }
}
