# ZBOOSTER

**Your Gaming Performance Companion** — a modern, lightweight Android Game
Booster app built with Kotlin, Jetpack Compose, and Material Design 3.

ZBOOSTER helps you organize your games, apply sensible performance/battery
profiles, and monitor real device metrics — using only what Android
legitimately allows a normal (non-root) app to do. It does not claim to
overclock your CPU/GPU, add physical RAM, or force-kill every other app.

---

## 1. Cara Membuka Project

1. Install **Android Studio** (Koala/2024.1 or newer recommended).
2. `File → Open` and select the `ZBOOSTER/` root folder (the one containing
   `settings.gradle.kts`).
3. Android Studio will detect this is a Gradle project and start syncing
   automatically. The Gradle wrapper (`gradlew`, `gradlew.bat`,
   `gradle/wrapper/gradle-wrapper.jar`) is already committed in this repo,
   so no extra setup step is needed — Android Studio (or `./gradlew` from
   the command line) works immediately.
4. Let Gradle sync finish (it will download dependencies — requires internet
   access on first sync).

## 2. Cara Build

**From Android Studio:**
- `Run ▶` on the `app` configuration to build + install on an emulator or
  connected device.
- `Build → Build Bundle(s) / APK(s) → Build APK(s)` for a standalone APK.

**From the command line:**
```bash
./gradlew assembleDebug     # debug APK -> app/build/outputs/apk/debug/
./gradlew assembleRelease   # release APK (unsigned unless you configure signing)
./gradlew installDebug      # build + install on a connected device/emulator
```

## 3. Dependencies

| Purpose | Library |
|---|---|
| UI | Jetpack Compose (BOM `2024.06.00`), Material 3 |
| Navigation | Navigation Compose |
| Architecture | ViewModel + StateFlow (MVVM) |
| Local DB | Room (game metadata: favorites, categories, profiles) |
| Preferences | Jetpack DataStore (theme, performance mode, toggles) |
| Async | Kotlin Coroutines + Flow |
| Splash | Core SplashScreen API |

`minSdk 24` (Android 7.0) — chosen as a realistic floor that covers the vast
majority of active Android devices, including older/low-end hardware,
while still allowing modern Compose APIs. `targetSdk 35`.

## 4. Permissions

ZBOOSTER follows **"request only what is needed"**: nothing is requested at
install time beyond what's declared in the manifest, and *runtime*
permissions/settings (Display over other apps, Notification access for DND)
are only requested when the user turns on the specific feature that needs
them (Overlay, DND) from Settings — never all at once, and always with an
explanation first (see the Onboarding flow, page 4).

| Permission | Why ZBOOSTER uses it | Requested when |
|---|---|---|
| `QUERY_ALL_PACKAGES` | Detect installed games for the Game Library, via the standard `PackageManager` API | Install time (declared; required to enumerate apps on Android 11+) |
| `SYSTEM_ALERT_WINDOW` | Draw the optional floating Game Overlay | Only if the user enables **Overlay** in Settings |
| `ACCESS_NOTIFICATION_POLICY` | Toggle Do Not Disturb while gaming | Only if the user enables **Do Not Disturb** in Settings |
| `POST_NOTIFICATIONS` | Show the "Boost/Monitor active" status notification (Android 13+) | When live monitoring/overlay is first started |
| `WAKE_LOCK` | Support the **Keep Screen On** toggle | Only while that toggle is active |
| `FOREGROUND_SERVICE` / `FOREGROUND_SERVICE_SPECIAL_USE` | Keep the live overlay/monitor running reliably while visible | Only while the overlay/live monitor is on-screen |

If the user denies a permission, ZBOOSTER **does not crash** — the related
feature simply shows a "Not available" / "Not supported on this device"
state instead (see the `NOT_SUPPORTED_ON_THIS_DEVICE` string and honest-null
handling throughout the Monitor and Home screens).

## 5. Fitur yang Memiliki Batasan Android (Jujur, Tanpa Klaim Palsu)

Per the requirement spec, ZBOOSTER never fabricates capability. Concretely:

- **Boost Now** only clears ZBOOSTER's own app cache and gives the JVM an
  advisory `System.gc()` hint. It does **not** add RAM, does **not**
  force-kill other apps (not permitted on modern Android without being the
  device owner/root), and does **not** overclock the CPU/GPU.
- **CPU usage** is shown as "Not available" — Android has no public,
  universal, non-root API for a normal app to read system-wide or per-app
  CPU usage.
- **Temperature** uses `BatteryManager.EXTRA_TEMPERATURE` (battery
  temperature) when available; if a device doesn't expose it, ZBOOSTER shows
  "Not available" rather than a made-up number.
- **FPS** is shown as "cannot be read universally on this device" unless a
  legitimate, documented FPS source exists — ZBOOSTER never fabricates an
  FPS counter.
- **Extreme profile** applies every legal, app-level optimization ZBOOSTER
  can perform (reducing its own background work, adjusting its own
  monitoring frequency, etc.) — it is explicitly documented as **not**
  overclocking hardware.

## 6. Cara Testing

**Unit tests** (`app/src/test/`):
```bash
./gradlew test
```
Recommended targets to add tests for as the project grows: `SettingsRepository`
(DataStore read/write), `DeviceCapability` (RAM classification thresholds),
`GameRepository` (merging PackageManager scan with Room metadata).

**Instrumented / UI tests** (`app/src/androidTest/`):
```bash
./gradlew connectedAndroidTest
```
Requires a running emulator or connected device. Compose UI test dependencies
(`ui-test-junit4`, `ui-test-manifest`) are already included in
`app/build.gradle.kts`.

**Manual testing checklist:**
- [ ] Fresh install → Onboarding shows all 4 pages → "Get Started" lands on Home
- [ ] Boost Now completes and shows "BOOST COMPLETE"
- [ ] Game Library shows installed games with correct icons/names; Search and
      each category filter (All/Recently Played/Favorite/High
      Performance/Custom) work
- [ ] Refresh Game List re-scans without crashing if a game was
      installed/uninstalled since last open
- [ ] Game Detail → changing Booster Profile persists after navigating away
      and back
- [ ] Performance Monitor: Start/Stop toggles polling; switching Live/Simple/
      Detailed changes the amount of information shown; app does not poll
      when monitoring is stopped
- [ ] Settings: every toggle persists after force-closing and reopening the
      app (DataStore-backed); Reset Settings restores defaults
- [ ] Rotate device / resize window (or test on a tablet & a small phone) —
      layout adapts columns/padding per `ZWindowSize` breakpoints without
      clipped text or overflowing buttons
- [ ] Deny the Overlay/DND permission when prompted — confirm the app does
      not crash and shows an appropriate disabled/unavailable state

## 7. CI/CD — Build APK Otomatis di GitHub Actions

Karena build Android butuh Google's Maven repo, Maven Central, dan server
distribusi Gradle (yang tidak semua lingkungan lokal/sandbox punya akses
ke sana), repo ini menyertakan dua workflow GitHub Actions yang jalan di
server GitHub sendiri (yang punya akses jaringan penuh):

- **`.github/workflows/build-apk.yml`** — jalan otomatis di setiap
  `push`/`pull_request` ke branch `main` (atau manual lewat tab *Actions →
  Run workflow*). Langkahnya:
  1. Setup JDK 17 dan Android SDK.
  2. `./gradlew test` — unit test (`app/src/test`), pakai wrapper yang
     sudah di-commit di repo ini (`gradlew`, `gradlew.bat`,
     `gradle/wrapper/gradle-wrapper.jar`).
  3. `./gradlew assembleDebug` — build APK debug sungguhan.
  4. Upload APK hasil build sebagai **Artifact** (bisa didownload dari
     halaman run di tab Actions), plus laporan unit test & lint.

- **`.github/workflows/android-instrumented-tests.yml`** — jalan manual
  (*Actions → Run workflow*) atau otomatis saat kamu publish GitHub
  Release. Menyalakan emulator Android sungguhan (API 29 & 34) lalu
  menjalankan `./gradlew connectedDebugAndroidTest` (test di
  `app/src/androidTest`) di dalamnya. Dipisah dari workflow utama karena
  boot emulator lebih lambat (~5–10 menit).

**Cara pakai:**
1. Push/upload folder `ZBOOSTER/` ini ke repository GitHub kamu.
2. Buka tab **Actions** di repo tersebut — workflow `Android CI (Build &
   Unit Test)` (`build-apk.yml`) akan otomatis berjalan.
3. Setelah selesai (hijau ✅), scroll ke bagian bawah halaman run tersebut
   → download APK dari **Artifacts** → `zbooster-debug-apk`.
4. Untuk instrumented test, buka **Actions → Android Instrumented Tests
   (Emulator) → Run workflow** secara manual.

Kalau build gagal (merah ❌), buka log step yang gagal di tab Actions —
pesan errornya akan jauh lebih detail daripada yang bisa saya berikan dari
sandbox ini, karena workflow ini benar-benar mengunduh dependency asli dari
Google Maven/Maven Central.

## 8. Struktur Folder Final

```
ZBOOSTER/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/zbooster/app/
│       │   ├── MainActivity.kt
│       │   ├── ZBoosterApplication.kt
│       │   ├── data/
│       │   │   ├── local/          # Room entities, DAO, database
│       │   │   └── repository/     # SettingsRepository, GameRepository
│       │   ├── manager/            # BoosterManager (honest boost logic)
│       │   ├── model/              # Game, DeviceStatus, PerformanceSample, ...
│       │   ├── service/            # BoosterMonitorService (foreground service)
│       │   ├── ui/
│       │   │   ├── components/     # ZCard, GameCard, settings rows, ...
│       │   │   ├── navigation/     # ZDestination, ZNavHost
│       │   │   ├── screens/        # home, games, gamedetail, boost, monitor,
│       │   │   │                   # settings, onboarding
│       │   │   └── theme/          # Color, Type, Shape, Theme, WindowSize,
│       │   │                       # PerformanceMode
│       │   └── util/                # DeviceCapability, InstalledAppsReader,
│       │                             # PerformanceSampler
│       └── res/
│           ├── drawable/           # ZBOOSTER logo + adaptive icon layers
│           ├── mipmap-anydpi-v26/  # adaptive launcher icon XML
│           ├── values/             # strings, colors, themes
│           └── xml/                # network security config
├── gradle/wrapper/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── README.md
```

## 9. Known Follow-Ups (Not Yet Implemented)

Fixed in this pass (previously "toggle only, no real effect"):
- Do Not Disturb & Game Overlay toggles now actually launch the real system
  permission screens (`ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS`,
  `ACTION_MANAGE_OVERLAY_PERMISSION`) via `util/PermissionHelper.kt`, show a
  short rationale first, and self-correct (auto-turn-off) if access is later
  revoked in system Settings.
- Keep Screen On now actually applies/clears `FLAG_KEEP_SCREEN_ON` on the
  window reactively (see `MainActivity.kt`), not just a stored boolean.
- Block Notifications is now backed by a real
  `service/ZNotificationBlockerService.kt` (`NotificationListenerService`)
  that cancels other apps' notification banners while the toggle is on and
  Notification Access is granted. It does **not** attempt to scope this to
  "only while a specific game is in the foreground" — that would need the
  separate `PACKAGE_USAGE_STATS` permission, which this app does not
  request; read the subtitle as "while this switch is on".
- `BoosterMonitorService` is now actually started/stopped from
  `MonitorViewModel` when live Performance Monitor is toggled on/off.
- Game Library detection now also matches known game-engine native
  libraries (Unity/Unreal/Cocos2d/Godot) as a fallback to
  `CATEGORY_GAME`, improving recall for real devices — still not
  exhaustive (see `InstalledAppsReader.kt` doc comment).
- The notification bell icon (Home) and the profile chip (Boost Profiles)
  are now both functional: the bell opens ZBOOSTER's system notification
  settings page, and the chip opens a short info dialog for that profile.
- Room database now has a `fallbackToDestructiveMigration()` safety net so
  a future schema-version bump without a real `Migration` doesn't crash
  existing users on update (trade-off: it wipes local game-metadata cache
  instead — replace with real migrations once the schema changes).
- Release builds can be signed by creating a git-ignored `keystore.properties`
  file at the project root with `storeFile`, `storePassword`, `keyAlias`,
  and `keyPassword` properties; without it, `./gradlew
  assembleRelease` still succeeds but produces an **unsigned** APK/AAB.

Fixed in this pass (previously "floating overlay UI has no code at all"):
- Implemented a real floating **Game Overlay panel** —
  `service/GameOverlayService.kt` + `res/layout/view_overlay_bubble.xml` +
  `res/layout/view_overlay_panel.xml`. It's a genuine `WindowManager`
  overlay (not a mock): draggable collapsed bubble, an expandable panel
  showing live RAM/Battery (same honest `DeviceCapability` readers used
  elsewhere in the app, no fabricated numbers), a working "Boost Now"
  button wired to the real `BoosterManager`, and minimize/close controls.
  The Settings > Gameplay "Game Overlay" toggle now actually starts/stops
  this service (only once "Display over other apps" is granted).
  Known trade-off: it runs as a plain (non-foreground) `Service`, so
  aggressive OEM battery-optimizers may still kill it in the background —
  making it a real foreground service would need its own persistent
  notification, which felt like the wrong default for something this
  lightweight; revisit if user reports show it getting killed often.

Still intentionally left for a future pass:
- Language selection (multi-locale) is not yet implemented.
- Unit/instrumented test files are documented above but not yet written.
- None of this has been verified with a real `./gradlew build` (no Android
  SDK/Gradle network access in the environment that produced these
  changes) — everything above was checked by careful manual reading of the
  Kotlin/Compose/Gradle APIs involved, not a real compiler run. Please run
  a real build before shipping and report back if anything doesn't compile.
- `QUERY_ALL_PACKAGES` will still require a Play Console declaration form
  at submission time, and `BIND_NOTIFICATION_LISTENER_SERVICE` (added for
  Block Notifications) is a sensitive permission Play may also ask about —
  budget time for that review step.
